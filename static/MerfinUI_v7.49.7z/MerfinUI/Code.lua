local E, L, V, P, G = unpack(ElvUI)
local EP = LibStub("LibElvUIPlugin-1.0")
local PI = E:GetModule('PluginInstaller')

local GetAddOnMetadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
local addonName, addonTable = ...

local screenWidth, screenHeight = GetPhysicalScreenSize()

addonTable.L = GetLocale()
addonTable.Name = '|cff40c7ebMerfinUI|r'
addonTable.Version = tonumber(GetAddOnMetadata(addonName, 'Version'))
addonTable.Resolution = screenWidth >= 2560 and 'QUAD_HD' or 'FULL_HD'
addonTable.ScreenHeight = screenHeight
addonTable.Font = 'Merfin Font 1'
addonTable.Texture = 'Merfin Main Texture'
addonTable.AceProfileName = string.format("%s - %s", UnitName("player"), GetRealmName("player"))
addonTable.MerfinProfileName = 'MerfinUI (' .. addonTable.ScreenHeight .. ') v' .. addonTable.Version

MUI = E:NewModule(addonName, 'AceConsole-3.0', 'AceHook-3.0', 'AceEvent-3.0', 'AceTimer-3.0')

MUI.addonTable = addonTable

local Initialize = function()

	if E.private.MUI.install_version == nil then
		PI:Queue(MUI.InstallerData)
	end

	EP:RegisterPlugin(addonName, MUI.Config)
	MUI:RegisterCommands()
end

E:RegisterModule(addonName, Initialize)