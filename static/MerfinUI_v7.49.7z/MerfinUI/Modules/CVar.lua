local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)
local SetCVar = SetCVar
local IsAddOnLoaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded

local merfinUI = 'MerfinUI v' .. addonTable.Version

local LoadClassColorsDB = function()

    if not IsAddOnLoaded("!ClassColors") then
        return
    end

    ClassColorsDB = {
        ["DEATHKNIGHT"] = {
            ["b"] = 0.2509803921568627,
            ["colorStr"] = "ffff3f3f",
            ["g"] = 0.2509803921568627,
            ["r"] = 1
        },
        ["WARRIOR"] = {
            ["b"] = 0.43,
            ["colorStr"] = "ffc69b6d",
            ["g"] = 0.61,
            ["r"] = 0.78
        },
        ["PALADIN"] = {
            ["b"] = 0.73,
            ["colorStr"] = "fff48cba",
            ["g"] = 0.55,
            ["r"] = 0.96
        },
        ["MAGE"] = {
            ["b"] = 0.92,
            ["colorStr"] = "ff3fc6ea",
            ["g"] = 0.78,
            ["r"] = 0.25
        },
        ["PRIEST"] = {
            ["b"] = 1,
            ["colorStr"] = "ffffffff",
            ["g"] = 1,
            ["r"] = 1
        },
        ["SHAMAN"] = {
            ["b"] = 0.8666667342185974,
            ["colorStr"] = "ff0070dd",
            ["g"] = 0.4392157196998596,
            ["r"] = 0
        },
        ["WARLOCK"] = {
            ["b"] = 0.93,
            ["colorStr"] = "ff8787ed",
            ["g"] = 0.53,
            ["r"] = 0.53
        },
        ["DEMONHUNTER"] = {
            ["b"] = 0.79,
            ["colorStr"] = "ffa330c9",
            ["g"] = 0.19,
            ["r"] = 0.64
        },
        ["ROGUE"] = {
            ["b"] = 0.41,
            ["colorStr"] = "fffff468",
            ["g"] = 0.96,
            ["r"] = 1
        },
        ["DRUID"] = {
            ["b"] = 0.04,
            ["colorStr"] = "ffff7c0a",
            ["g"] = 0.49,
            ["r"] = 1
        },
        ["MONK"] = {
            ["b"] = 0.59,
            ["colorStr"] = "ff00ff96",
            ["g"] = 1,
            ["r"] = 0
        },
        ["HUNTER"] = {
            ["b"] = 0.45,
            ["colorStr"] = "ffaad372",
            ["g"] = 0.83,
            ["r"] = 0.67
        }
    }

end

local LoadTalentedDB = function()

    if not IsAddOnLoaded("Talented") then
        return
    end

    TalentedDB["profiles"][merfinUI] = TalentedDB["profiles"][merfinUI] or {}
    TalentedDB["profiles"][merfinUI]["offset"] = 55
    TalentedDB["profiles"][merfinUI]["always_edit"] = true
    TalentedDB["profiles"][merfinUI]["framepos"] = {
        ["TalentedFrame"] = {
            ["y"] = 103.4998550415039,
            ["x"] = 408.0003051757813,
            ["anchorTo"] = "LEFT",
            ["anchor"] = "LEFT"
        }
    }

    TalentedDB["profileKeys"] = TalentedDB["profileKeys"] or {}
    TalentedDB["profileKeys"][addonTable.AceProfileName] = merfinUI

end

local LoadTomTomDB = function()

    if not IsAddOnLoaded("TomTom") then
        return
    end

    TomTomDB["profiles"][merfinUI] = TomTomDB["profiles"][merfinUI] or {}

    TomTomDB["profiles"][merfinUI]["arrow"] = TomTomDB["profiles"][merfinUI]["arrow"] or {}
    TomTomDB["profiles"][merfinUI]["arrow"]["position"] = {"TOP", -- [1]
    nil, -- [2]
    "TOP", -- [3]
    0, -- [4]
    -350 -- [5]
    }

    TomTomDB["profiles"][merfinUI]["block"] = TomTomDB["profiles"][merfinUI]["block"] or {}
    TomTomDB["profiles"][merfinUI]["block"]["enable"] = false
    TomTomDB["profiles"][merfinUI]["block"]["width"] = 130
    TomTomDB["profiles"][merfinUI]["block"]["fontsize"] = 17
    TomTomDB["profiles"][merfinUI]["block"]["position"] = {"TOP", -- [1]
    nil, -- [2]
    "TOP", -- [3]
    0, -- [4]
    -70 -- [5]
    }
    TomTomDB["profiles"][merfinUI]["block"]["height"] = 40

    TomTomDB["profileKeys"] = TomTomDB["profileKeys"] or {}
    TomTomDB["profileKeys"][addonTable.AceProfileName] = merfinUI

end

local LoadQuestieDB = function()

    if not IsAddOnLoaded("Questie") then
        return
    end

    QuestieConfig["profiles"][merfinUI] = QuestieConfig["profiles"][merfinUI] or {}

    QuestieConfig["profiles"][merfinUI]["trackerFontObjective"] = addonTable.Font
    QuestieConfig["profiles"][merfinUI]["trackerFontZone"] = addonTable.Font
    QuestieConfig["profiles"][merfinUI]["trackerFontQuest"] = addonTable.Font
    QuestieConfig["profiles"][merfinUI]["trackerSetpoint"] = "TOPRIGHT"
    QuestieConfig["profiles"][merfinUI]["trackerFontHeader"] = addonTable.Font
    QuestieConfig["profiles"][merfinUI]["trackerEnabled"] = false

    if MUI:GetProfileResolution() == 'QUAD_HD' then

        QuestieConfig["profiles"][merfinUI]["TrackerLocation"] = {"TOPRIGHT", -- [1]
        "UIParent", -- [2]
        "TOPRIGHT", -- [3]
        -0, -- [4]
        -278.5003662109375 -- [5]
        }

        QuestieConfig["profiles"][merfinUI]["trackerFontSizeZone"] = 15
        QuestieConfig["profiles"][merfinUI]["trackerFontSizeHeader"] = 15
        QuestieConfig["profiles"][merfinUI]["trackerFontSizeObjective"] = 15
        QuestieConfig["profiles"][merfinUI]["trackerFontSizeQuest"] = 15
        QuestieConfig["profiles"][merfinUI]["TrackerHeight"] = 669.0003662109375
        QuestieConfig["profiles"][merfinUI]["TrackerWidth"] = 297.0004577636719

    elseif MUI:GetProfileResolution() == 'FULL_HD' then

        QuestieConfig["profiles"][merfinUI]["TrackerLocation"] = {"TOPRIGHT", -- [1]
        "UIParent", -- [2]
        "TOPRIGHT", -- [3]
        -14.0001220703125, -- [4]
        -258.499755859375 -- [5]
        }

        QuestieConfig["profiles"][merfinUI]["trackerFontSizeZone"] = 13
        QuestieConfig["profiles"][merfinUI]["trackerFontSizeHeader"] = 13
        QuestieConfig["profiles"][merfinUI]["trackerFontSizeObjective"] = 13
        QuestieConfig["profiles"][merfinUI]["trackerFontSizeQuest"] = 13
        QuestieConfig["profiles"][merfinUI]["TrackerHeight"] = 360
        QuestieConfig["profiles"][merfinUI]["TrackerWidth"] = 249

    end

    QuestieConfig["profileKeys"] = QuestieConfig["profileKeys"] or {}
    QuestieConfig["profileKeys"][addonTable.AceProfileName] = merfinUI
end

local LoadLeatrixDB = function()

    LeaPlusDB = LeaPlusDB or {}
    LeaPlusDB.EnhanceProfessions = "On"
    LeaPlusDB.EnhanceQuestDifficulty = "On"

    LeaPlusDB = {
        ["HideMiniZoomBtns"] = "Off",
        ["ViewPortBottom"] = 0,
        ["BuffFrameX"] = -205,
        ["MuteCustomList"] = "",
        ["ManageWidget"] = "Off",
        ["TimerY"] = -96,
        ["SetWeatherDensity"] = "Off",
        ["ClassColPlayer"] = "On",
        ["ShowMinimapIcon"] = "On",
        ["TipCursorY"] = 0,
        ["FlightBarContribute"] = "On",
        ["InvKey"] = "inv",
        ["FlightBarY"] = -66,
        ["MinimapR"] = "TOPRIGHT",
        ["NoGryphons"] = "Off",
        ["FrmEnabled"] = "Off",
        ["TipCursorX"] = 0,
        ["MinimapModder"] = "Off",
        ["LeaStartPage"] = 5,
        ["FlightBarSpeech"] = "Off",
        ["DressupItemButtons"] = "On",
        ["DismountNoTaxi"] = "On",
        ["InviteFromWhisper"] = "Off",
        ["MinimapScale"] = 1,
        ["TimerScale"] = 1,
        ["MuteYawns"] = "Off",
        ["AutoReleasePvP"] = "Off",
        ["HideMacroText"] = "Off",
        ["MinimapX"] = -17,
        ["AutoResNoCombat"] = "On",
        ["WowheadLinkComments"] = "Off",
        ["VanityAltLayout"] = "Off",
        ["TipHideInCombat"] = "Off",
        ["UseArrowKeysInChat"] = "Off",
        ["ManageDurability"] = "Off",
        ["AcceptPartyFriends"] = "Off",
        ["PlusPanelAlpha"] = 0,
        ["WidgetX"] = 0,
        ["FlightBarWidth"] = 230,
        ["RestoreChatMessages"] = "Off",
        ["FirstRunMessageSeen"] = true,
        ["NoCooldownDuration"] = "On",
        ["MuteGameSounds"] = "Off",
        ["SquareMinimap"] = "Off",
        ["DismountNoMoving"] = "On",
        ["KeepAudioSynced"] = "Off",
        ["NoRestedEmotes"] = "Off",
        ["MuteScreech"] = "Off",
        ["CombatPlates"] = "Off",
        ["FlightBarA"] = "TOP",
        ["TipHideShiftOverride"] = "On",
        ["HideZoneText"] = "Off",
        ["TimerX"] = -5,
        ["EnhanceDressup"] = "Off",
        ["ShowFlightTimes"] = "Off",
        ["RecentChatSize"] = 170,
        ["NoBagAutomation"] = "Off",
        ["ShowWhoPinged"] = "On",
        ["UseEasyChatResizing"] = "Off",
        ["MoreFontSizes"] = "Off",
        ["AutoQuestShift"] = "Off",
        ["HideMiniAddonButtons"] = "On",
        ["LeaPlusQuestFontSize"] = 12,
        ["TipShowTarget"] = "On",
        ["CharAddonList"] = "Off",
        ["BuffFrameY"] = -13,
        ["MuteChimes"] = "Off",
        ["MusicContinent"] = "Zones",
        ["NoDuelRequests"] = "Off",
        ["FlightBarBackground"] = "On",
        ["AhExtras"] = "Off",
        ["ViewPortTop"] = 0,
        ["MinimapSize"] = 140,
        ["QuestFontChange"] = "Off",
        ["HideErrorMessages"] = "Off",
        ["TipOffsetX"] = -13,
        ["BlockDuelSpam"] = "Off",
        ["FriendlyGuild"] = "On",
        ["MainPanelR"] = "CENTER",
        ["WidgetScale"] = 1,
        ["DurabilityScale"] = 1,
        ["FlightMapX"] = 0,
        ["EnhanceQuestTaller"] = "On",
        ["AhBuyoutOnly"] = "Off",
        ["BuffFrameScale"] = 1,
        ["FlightMapR"] = "TOPLEFT",
        ["DressupAnimControl"] = "On",
        ["NoClassBar"] = "Off",
        ["DismountNoResource"] = "On",
        ["TimerR"] = "TOP",
        ["FlightBarFillBar"] = "Off",
        ["UnivGroupColor"] = "Off",
        ["EnhanceQuestDifficulty"] = "On",
        ["TooltipAnchorMenu"] = 1,
        ["NoScreenEffects"] = "Off",
        ["MinimapNoScale"] = "Off",
        ["EnhanceProfessions"] = "On",
        ["MainPanelX"] = 447.9999084472656,
        ["AutoSellExcludeList"] = "",
        ["DurabilityY"] = -192,
        ["ShowVolume"] = "Off",
        ["NoPartyInvites"] = "Off",
        ["WidgetY"] = -15,
        ["MinimapA"] = "TOPRIGHT",
        ["EnhanceQuestLog"] = "On",
        ["MuteReady"] = "Off",
        ["ViewPortLeft"] = 0,
        ["MuteCustomSounds"] = "Off",
        ["BlockDrunkenSpam"] = "Off",
        ["FlightBarScale"] = 2,
        ["MainPanelY"] = -3.000022411346436,
        ["MuteStriders"] = "Off",
        ["MaxCameraZoom"] = "Off",
        ["AutoQuestAvailable"] = "On",
        ["FasterMovieSkip"] = "Off",
        ["BuffFrameA"] = "TOPRIGHT",
        ["PlusPanelScale"] = 1,
        ["CooldownsOnPlayer"] = "Off",
        ["ShowWowheadLinks"] = "Off",
        ["ShowFreeBagSlots"] = "Off",
        ["HideMiniClock"] = "Off",
        ["EasyItemDestroy"] = "Off",
        ["AutoQuestCompleted"] = "On",
        ["FasterLooting"] = "Off",
        ["NoConfirmLoot"] = "Off",
        ["ClassColFrames"] = "Off",
        ["WidgetA"] = "TOP",
        ["NoStickyChat"] = "Off",
        ["ViewPortResizeBottom"] = 0,
        ["LeaPlusMailFontSize"] = 15,
        ["ViewPortResizeTop"] = 0,
        ["WidgetR"] = "TOP",
        ["StandAndDismount"] = "Off",
        ["NoFriendRequests"] = "Off",
        ["AutoRepairShowSummary"] = "On",
        ["AhGoldOnly"] = "Off",
        ["FlightBarDestination"] = "On",
        ["ShowBagSearchBox"] = "Off",
        ["DurabilityStatus"] = "Off",
        ["NoChatButtons"] = "Off",
        ["EnhanceQuestLevels"] = "On",
        ["MuteLogin"] = "Off",
        ["ViewPortRight"] = 0,
        ["NoCombatLogTab"] = "Off",
        ["TipNoHealthBar"] = "Off",
        ["ClassColorsInChat"] = "Off",
        ["ManageBuffs"] = "Off",
        ["MoveChatEditBoxToTop"] = "Off",
        ["ViewPortEnable"] = "Off",
        ["BuffFrameR"] = "TOPRIGHT",
        ["ShowRaidToggle"] = "Off",
        ["ShowVendorPrice"] = "Off",
        ["MinimapY"] = -22,
        ["MiniExcludeList"] = "",
        ["NoChatFade"] = "Off",
        ["MuteMechSteps"] = "Off",
        ["NoScreenGlow"] = "Off",
        ["AutoQuestKeyMenu"] = 1,
        ["FilterChatMessages"] = "Off",
        ["ViewPortAlpha"] = 0,
        ["AutoAcceptSummon"] = "Off",
        ["DurabilityX"] = 0,
        ["FlightBarR"] = "TOP",
        ["LeaPlusTaxiIconSize"] = 10,
        ["UnclampChat"] = "Off",
        ["LeaPlusTaxiMapScale"] = 1.9,
        ["LeaPlusBookFontSize"] = 15,
        ["MaxChatHstory"] = "Off",
        ["MailFontChange"] = "Off",
        ["FlightBarX"] = 0,
        ["MuteTrains"] = "Off",
        ["MainPanelA"] = "CENTER",
        ["CombineAddonButtons"] = "Off",
        ["TipShowRank"] = "On",
        ["PlayerChainMenu"] = 2,
        ["TipModEnable"] = "Off",
        ["HideMiniTracking"] = "Off",
        ["ShowTrainAllBtn"] = "On",
        ["ShowPlayerChain"] = "Off",
        ["FlightMapY"] = 61,
        ["MuteInterface"] = "Off",
        ["EnhanceTrainers"] = "On",
        ["AutoSellJunk"] = "Off",
        ["AutoRepairGear"] = "Off",
        ["WeatherLevel"] = 3,
        ["ManageTimer"] = "Off",
        ["AutoAcceptRes"] = "Off",
        ["ShowReadyTimer"] = "Off",
        ["AutoSellShowSummary"] = "On",
        ["TipOffsetY"] = 94,
        ["AutomateGossip"] = "Off",
        ["NoSharedQuests"] = "Off",
        ["ShowCooldowns"] = "Off",
        ["BookFontChange"] = "Off",
        ["HideMiniZoneText"] = "Off",
        ["ShowVanityControls"] = "Off",
        ["LeaPlusTipSize"] = 1,
        ["MuteFizzle"] = "Off",
        ["HideDressupStats"] = "Off",
        ["TimerA"] = "TOP",
        ["RecentChatWindow"] = "Off",
        ["hide"] = false,
        ["HideKeybindText"] = "Off",
        ["MiniClusterScale"] = 1,
        ["FlightMapA"] = "TOPLEFT",
        ["TipShowOtherRank"] = "Off",
        ["ShowCooldownID"] = "On",
        ["NoHitIndicators"] = "Off",
        ["EnhanceFlightMap"] = "On",
        ["AutoReleaseNoAlterac"] = "Off",
        ["InviteFriendsOnly"] = "Off",
        ["ShowDruidPowerBar"] = "Off",
        ["AutoReleaseDelay"] = 200,
        ["ClassColTarget"] = "On",
        ["AutomateQuests"] = "Off",
        ["DurabilityR"] = "TOPRIGHT",
        ["DurabilityA"] = "TOPRIGHT"
    }

end

local LoadPallyPowerDB = function()

    if not PallyPowerDB then
        return
    end
    local newProfileName = 'MerfinUI v' .. addonTable.Version

    PallyPowerDB["profiles"] = PallyPowerDB["profiles"] or {}
    PallyPowerDB["profileKeys"] = PallyPowerDB["profileKeys"] or {}

    PallyPowerDB["profiles"][newProfileName] = {
        ["auras"] = false,
        ["skin"] = "normTex2",
        ["rfbuff"] = false,
        ["enable"] = true,
        ["border"] = "None",
        ["WrathTransition"] = true,
        ["hideHighGroups"] = true,
        ["rf"] = false
    }

    PallyPowerDB["profileKeys"][addonTable.AceProfileName] = newProfileName

    PallyPowerFrame:ClearAllPoints()

    if MUI:GetProfileResolution() == 'QUAD_HD' then
        PallyPowerFrame:SetPoint("CENTER", "UIParent", "LEFT", 210, 125)
    elseif MUI:GetProfileResolution() == 'FULL_HD' then
        PallyPowerFrame:SetPoint("CENTER", "UIParent", "LEFT", 210, 125)
    end

    PallyPowerFrame:SetUserPlaced(true)
end

local LoadBagSackDB = function()

    BugSackDB = {
        ["auto"] = false,
        ["fontSize"] = "GameFontHighlight",
        ["useMaster"] = false,
        ["altwipe"] = true,
        ["mute"] = true,
        ["soundMedia"] = "BugSack: Fatality",
        ["chatframe"] = false
    }

    BugSackLDBIconDB = {}

end

local ImportLayout = function(layoutString, layoutName)
    -- Импортируем макет из строки
    local isSuccessful, importedLayoutID = EditModeManagerFrame:ImportLayout(layoutString)

    if isSuccessful then
        -- Переименовываем макет, чтобы он соответствовал заданному названию
        for _, layout in ipairs(EditModeManagerFrame:GetLayouts()) do
            if layout.layoutID == importedLayoutID then
                layout.layoutName = layoutName
                EditModeManagerFrame:SaveLayout(layoutName) -- Сохраняем переименованный макет
                print("Layout успешно импортирован и сохранён как: " .. layoutName)
                return
            end
        end
    else
        print("Ошибка: не удалось импортировать макет.")
    end
end

local LoadEditMode = function()
    local layoutString = MUI:GetProfileResolution() == 'QUAD_HD' and
                             "1 39 0 0 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&('%)#+#,$ 0 1 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&('%(#,$ 0 2 1 7 7 UIParent 0.0 45.0 -1 ##$$%/&('%(#,$ 0 3 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&('%(#,$ 0 4 1 5 5 UIParent -5.0 -77.0 -1 #$$$%/&('%(#,$ 0 5 1 1 4 UIParent 0.0 0.0 -1 ##$$%/&('%(#,$ 0 6 1 1 4 UIParent 0.0 -50.0 -1 ##$$%/&('%(#,$ 0 7 1 1 4 UIParent 0.0 -100.0 -1 ##$$%/&('%(#,$ 0 10 1 7 7 UIParent 0.0 45.0 -1 ##$$&('% 0 11 1 7 7 UIParent 0.0 45.0 -1 ##$$&('%,# 0 12 1 7 7 UIParent 0.0 45.0 -1 ##$$&('% 1 -1 1 4 4 UIParent 0.0 0.0 -1 ##$#%# 2 -1 1 2 2 UIParent 0.0 0.0 -1 ##$#%( 3 0 1 8 7 UIParent -300.0 250.0 -1 $#3# 3 1 1 6 7 UIParent 300.0 250.0 -1 %#3# 3 2 1 6 7 UIParent 520.0 265.0 -1 %#&#3# 3 3 1 0 2 CompactRaidFrameManager 0.0 -7.0 -1 '#(#)#-#.#/#1$3# 3 4 1 0 2 CompactRaidFrameManager 0.0 -5.0 -1 ,#-#.#/#0#1#2( 3 5 1 5 5 UIParent 0.0 0.0 -1 &#*$3# 3 6 1 5 5 UIParent 0.0 0.0 -1 -#.#/#4$ 3 7 1 4 4 UIParent 0.0 0.0 -1 3# 4 -1 1 7 7 UIParent 0.0 45.0 -1 # 5 -1 1 7 7 UIParent 0.0 45.0 -1 # 6 0 1 2 2 UIParent -255.0 -10.0 -1 ##$#%#&.(()( 6 1 1 2 2 UIParent -270.0 -155.0 -1 ##$#%#'+(()( 7 -1 0 0 0 UIParent 13.5 -146.5 -1 # 8 -1 0 6 6 UIParent 35.0 50.0 -1 #'$A%$&7 9 -1 1 7 7 UIParent 0.0 45.0 -1 # 10 -1 1 0 0 UIParent 16.0 -116.0 -1 # 11 -1 1 8 8 UIParent -9.0 85.0 -1 # 12 -1 0 5 5 UIParent -8.0 123.0 -1 #A$#%# 13 -1 1 8 8 MicroButtonAndBagsBar 0.0 0.0 -1 ##$#%)&- 14 -1 1 2 2 MicroButtonAndBagsBar 0.0 10.0 -1 ##$#%( 15 0 1 7 7 StatusTrackingBarManager 0.0 0.0 -1 # 15 1 1 7 7 StatusTrackingBarManager 0.0 17.0 -1 # 16 -1 1 5 5 UIParent 0.0 0.0 -1 #( 17 -1 1 1 1 UIParent 0.0 -100.0 -1 ## 18 -1 1 5 5 UIParent 0.0 0.0 -1 #- 19 -1 1 7 7 UIParent 0.0 0.0 -1 ##"
    ImportLayout(layoutString, 'MerfinUI')
end

local LoadWarpDeplete = function()

    if not E:IsAddOnEnabled("WarpDeplete") then
        DEFAULT_CHAT_FRAME:AddMessage("|cffbefc03MerfinUI:|r You need to enable WarpDeplete to apply profile settings!")
        return
    end

    local profileName = 'MerfinUI (' .. addonTable.ScreenHeight .. ') v' .. addonTable.Version

    WarpDepleteDB["profiles"] = WarpDepleteDB["profiles"] or {}

    WarpDepleteDB["profiles"][profileName] = MUI:GetProfileResolution() == 'QUAD_HD' and {
        ["objectivesFontSize"] = 15,
        ["keyFontSize"] = 17,
        ["timerFontSize"] = 23,
        ["frameX"] = 12.00026416778565,
        ["keyDetailsFontSize"] = 15,
        ["frameAnchor"] = "TOPRIGHT",
        ["frameY"] = -287.199951171875,
        ["deathsFontSize"] = 15
    } or MUI:GetProfileResolution() == 'FULL_HD' and {
        ["keyFontSize"] = 13,
        ["bar2FontSize"] = 13,
        ["deathsFontSize"] = 13,
        ["frameX"] = 16.00038146972656,
        ["keyDetailsFontSize"] = 12,
        ["frameY"] = 181.4999542236328,
        ["bar3FontSize"] = 13,
        ["bar1FontSize"] = 13,
        ["objectivesFontSize"] = 13,
        ["timerFontSize"] = 17,
        ["forcesFontSize"] = 13,
        ["barWidth"] = 246
    }

    WarpDepleteDB["profileKeys"] = WarpDepleteDB["profileKeys"] or {}
    WarpDepleteDB["profileKeys"][addonTable.AceProfileName] = profileName

end

local LoadMerfinPlusDB = function()
    MerfinPlusSaved = MerfinPlusSaved or {}

    MerfinPlusSaved["profiles"] = MerfinPlusSaved["profiles"] or {}
    MerfinPlusSaved["profileKeys"] = MerfinPlusSaved["profileKeys"] or {}

    local profileName = 'MerfinUI (' .. addonTable.Version .. ')'

    MerfinPlusSaved["profiles"][profileName] = {
        ["font1"] = "SFUIDisplayCondensed-Semibold",
        ["font2"] = "SFUIDisplayCondensed-Semibold",
    }

    MerfinPlusSaved["profileKeys"][addonTable.AceProfileName] = profileName
end

function MUI:Set_CVars()

    local CVars = {
        -- Character CVars
        nameplateShowOnlyNames = 0, -- To Show Friendly Names
        nameplateShowDebuffsOnFriendly = 0,
        nameplateShowEnemies = 1,
        nameplateSelectedScale = 1,
        nameplateShowFriendlyPets = 0,
        ShowClassColorInNameplate = 1,
        nameplateMotion = 1,
        NameplatePersonalHideDelayAlpha = 1,
        nameplateShowFriendlyNPCs = 0,
        NamePlateHorizontalScale = 1,
        nameplateMaxDistance = 41,
        NamePlateClassificationScale = 1,
        nameplateShowFriends = 0,
        nameplateSelectedAlpha = 1,
        nameplateShowEnemyGuardians = 1,
        lfgSelectedRoles = 8,
        nameplateShowOnlyNames = 1,
        autoLootDefault = 1,
        nameplateShowEnemyTotems = 1,
        nameplateNotSelectedAlpha = 1,
        consolidateBuffs = 1,
        nameplateRemovalAnimation = 1,
        clampTargetNameplateToScreen = 1,
        nameplateMinScale = 1,
        autoFilledMultiCastSlots = 15,
        nameplateLargerScale = 1.1,
        nameplateShowEnemyPets = 1,
        -- SoftTargetEnemy = 3,
        nameplateShowEnemyMinions = 1,
        -- Accounts CVars
        cameraDistanceMaxZoomFactor = 4,
        wholeChatWindowClickable = 0,
        lockActionBars = 1,
        showTutorials = 0,
        showNewbieTips = 0,
        floatingCombatTextCombatDamageDirectionalScale = 1,
        profanityFilter = 0,
        talentFrameShown = 1,
        scriptErrors = 1,
        floatingCombatTextLowManaHealth = 0,
        instantQuestText = 1,
        guildShowOffline = 0,
        UnitNameFriendlyPetName = 0,
        UnitNameFriendlyTotemName = 0,
        alwaysShowActionBars = 1,
        colorChatNamesByClass = 1,
        floatingCombatTextCombatDamageAllAutos = 0,
        floatingCombatTextFloatMode = 0,
        deselectOnClick = 1,
        showTargetOfTarget = 1,
        cameraYawMoveSpeed = 160,
        cameraPitchMoveSpeed = 80,
        floatingCombatTextCombatLogPeriodicSpells = 0,
        addFriendInfoShown = 1,
        floatingCombatTextCombatDamage = 1,
        floatingCombatTextCombatHealing = 1,
        UnitNameFriendlyGuardianName = 0,
        floatingCombatTextReactives = 0,
        lootUnderMouse = 1,
        nameplateTargetRadialPosition = 1,
        UnitNameFriendlyMinionName = 0,
        UnitNameNPC = 1,
        floatingCombatTextPetMeleeDamage = 0,
        AllowDangerousScripts = 1,
        showKeyring = 1,
        floatingCombatTextPetSpellDamage = 0,
        cameraSmoothStyle = 0
    }

    for CVar, variable in pairs(CVars) do
        SetCVar(CVar, variable)
    end

    LoadLeatrixDB()
    LoadQuestieDB()
    LoadPallyPowerDB()
    LoadBagSackDB()
    LoadTomTomDB()
    LoadTalentedDB()
    LoadClassColorsDB()
    LoadMerfinPlusDB()

    if E.Retail then
        -- LoadEditMode()
        LoadWarpDeplete()
    end

    addonTable:PluginInstallStepComplete(L["Account Settings"])
end
