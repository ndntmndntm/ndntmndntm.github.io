local addonName, addonTable = ...
local DisableAddOn = DisableAddOn or C_AddOns.DisableAddOn
local E, L, V, P, G = unpack(ElvUI)

local ElvUiFramesVisibility = function(show)
    E.db.unitframe.units = E.db.unitframe.units or {}

    E.db.unitframe.units.party = E.db.unitframe.units.party or {}
    E.db.unitframe.units.party.enable = show

    E.db.unitframe.units.raid1 = E.db.unitframe.units.raid1 or {}
    E.db.unitframe.units.raid1.enable = show

    E.db.unitframe.units.raid2 = E.db.unitframe.units.raid2 or {}
    E.db.unitframe.units.raid2.enable = show

    E.db.unitframe.units.raid3 = E.db.unitframe.units.raid3 or {}
    E.db.unitframe.units.raid3.enable = show
end

local LoadCellDebuffs = function()
    CellDB = CellDB or {}
    CellDB["raidDebuffs"] = {
        [316] = {
            ["general"] = {
                [110963] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [130857] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [688] = {
                [115291] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [115309] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [115297] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [324] = {
            [738] = {
                [120778] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [727] = {
                [121442] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [121447] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [119354] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [131655] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [121114] = {
                    ["order"] = 9,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [119840] = {
                    ["order"] = 8,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [121116] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [120938] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [122259] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [121421] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [122246] = {
                    ["order"] = 7,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [693] = {
                [119941] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [317] = {
            [726] = {
                [132226] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [117949] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [132222] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [679] = {
                [116322] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [130774] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116281] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [125206] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [130395] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116199] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116304] = {
                    ["order"] = 8,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116301] = {
                    ["order"] = 7,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [121245] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [118566] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116606] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116990] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [689] = {
                [116784] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116417] = {
                    ["glowOptions"] = {{0.95, 0.95, 0.32, 1}, 9, 0.25, 8, 2},
                    ["trackByID"] = false,
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["glowType"] = "None"
                },
                [131788] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116942] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [131790] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [131792] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [687] = {
                [117708] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [118303] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [118135] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [118048] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [682] = {
                [122151] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116161] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116278] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [677] = {
                [116525] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116550] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116778] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [116829] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [117485] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [63] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 7,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [64] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 16,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [66] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 16,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [68] = {
            ["general"] = {
                [88314] = {
                    ["order"] = 7,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [88175] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [103628] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [70] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 13,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [73963] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [303] = {
            [649] = {
                [111600] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [111723] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [115436] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [115419] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [676] = {
                [107122] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [675] = {
                [106933] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [655] = {
                [107268] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [311] = {
            [656] = {
                [113653] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [113690] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [113855] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [128164] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114011] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [128232] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [113436] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [654] = {
                [112955] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [660] = {
                [114056] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114004] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [312] = {
            [686] = {
                [107087] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [107200] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [126115] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [113022] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [106929] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [131241] = {
                    ["order"] = 8,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [112999] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [115509] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [115630] = {
                    ["order"] = 7,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [113020] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [657] = {
                [118961] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [673] = {
                [107140] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [685] = {
                [106827] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [127576] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [130701] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [106872] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [320] = {
            [742] = {
                [122752] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [122777] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [123011] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [709] = {
                [125786] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [129147] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [120629] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [119086] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [119985] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            },
            [683] = {
                [125760] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [111850] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [117353] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [729] = {
                [123121] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [125760] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [125758] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [130115] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [313] = {
            [335] = {
                [106113] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [658] = {
                [107110] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [118540] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [106841] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [106823] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [106653] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [110125] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114803] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [110099] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [321] = {
            [698] = {
                [119684] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [121185] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [118903] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [120562] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [690] = {
                [118963] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [708] = {
                [119946] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [120160] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [123655] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [246] = {
            [663] = {
                [114038] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [665] = {},
            ["general"] = {
                [114873] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                },
                [111594] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [111801] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114479] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [111813] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114860] = {
                    ["order"] = 7,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114493] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [666] = {
                [115350] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [111585] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            },
            [659] = {
                [111631] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [111610] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [684] = {
                [113141] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
        },
        [65] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 13,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [67] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 10,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [69] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 8,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            },
            [119] = {
                [82139] = {
                    ["order"] = 0,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [71] = {
            ["general"] = {
                [103628] = {
                    ["order"] = 20,
                    ["condition"] = {"None"},
                    ["trackByID"] = true
                }
            }
        },
        [302] = {
            ["general"] = {
                [106648] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114548] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [114381] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [106546] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [106851] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        },
        [330] = {
            [737] = {
                [125502] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [121949] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [744] = {
                [123474] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [123017] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [713] = {
                [122835] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [741] = {
                [121881] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [122064] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [743] = {
                [123707] = {
                    ["order"] = 5,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [123788] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [124849] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [124777] = {
                    ["order"] = 6,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [125390] = {
                    ["order"] = 4,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [124863] = {
                    ["order"] = 3,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            [745] = {
                [122740] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [122761] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            },
            ["general"] = {
                [123175] = {
                    ["order"] = 1,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                },
                [123017] = {
                    ["order"] = 2,
                    ["condition"] = {"None"},
                    ["trackByID"] = false
                }
            }
        }
    }
end

function MUI:ApplyCellColorTheme(theme)

    if not E:IsAddOnEnabled("Cell") then 
        DEFAULT_CHAT_FRAME:AddMessage("|cffbefc03MerfinUI:|r You need to enable Cell!")
        return
    end 

    local ChangeIndicatorNameColor = function(theme)
        for _, layout in pairs(CellDB.layouts) do  
            if layout.indicators then
                for i = 1, #layout.indicators do
                    local indicator = layout.indicators[i]
                    if indicator.indicatorName == 'nameText' then
                        indicator.color = theme == 'DARK' and {"class_color", {1, 1, 1}} or {"custom_color", {1, 1, 1}}
                    end
                end
            end
        end
    end

    CellDB.appearance = CellDB.appearance or {}
    CellDB.appearance.lossColor = CellDB.appearance.lossColor or {}
    CellDB.appearance.barColor = CellDB.appearance.barColor or {}

    if theme == 'NORMAL' then
        CellDB.appearance.barAlpha = 1
        CellDB.appearance.bgAlpha = 0.5
        CellDB.appearance.lossAlpha = 0.8

        CellDB.appearance.barColor[1] = "class_color"
        CellDB.appearance.barColor[2] = {0.8200000077486038, 0.6794286782569355, 0.6794286782569355}

        CellDB.appearance.lossColor[1] = "custom"
        CellDB.appearance.lossColor[2] = {0.1899999976158142, 0.1574285924106084, 0.1574285924106084}

        ChangeIndicatorNameColor('NORMAL')
    else
        CellDB.appearance.barAlpha = 0.8
        CellDB.appearance.bgAlpha = 0.5
        CellDB.appearance.lossAlpha = 0.8

        CellDB.appearance.barColor[1] = "custom"
        CellDB.appearance.barColor[2] = {0.1803921568627451, 0.1607843137254902, 0.1607843137254902}

        CellDB.appearance.lossColor[1] = "custom"
        CellDB.appearance.lossColor[2] = {0.8200000077486038, 0.6794286782569355, 0.6794286782569355}

        -- Changing color of Name
        ChangeIndicatorNameColor('DARK')
    end
end

local ImportCell = function()
    if not E:IsAddOnEnabled("Cell") then 
        DEFAULT_CHAT_FRAME:AddMessage("|cffbefc03MerfinUI:|r You need to enable Cell!")
        return
    end 

    local profileString = ''

    if MUI:GetProfileResolution() == 'QUAD_HD' then
        profileString = '!CELL:258:ALL!T3xd8Xr1rE62J1jB5nRT1h2YFquJXX2AWY2s2sgeX4mJMrwJTKgXOr2ydSQ7zMEupw9mDt39iBd4qqyCiKKn3PL17U3Uzpq4n3M7YrwlmClxIJbXhH1lbErWseztoseS4KaztIpso(T)2l5Q61DpDpDlzl5piWpq)WdZ866vv9Qx9Q3)x19udZ9Uc1(eYjOYl9SQP5tjenVoNsLIzsjexwwspJIwKCTiNnbVo3OzfYLVlzTm6zKZnSUSsVjK11LZoOUkFonPm6IklIxA)8huRhLu86cbYRYRjoHqo(esf4gNYIqMhukZTDB8QP6Ixv)GCJLwLpRqxQzKvZOFWM9hSd(m548pu3kY6sz6tux0)O3q(mj7NnGMwgnDXesYj7xiLOsL51eArsiFBc8s6IgYvvuzHoLrm(mP4uwOUPgync27WbJgpE0oApCRXvdjKMpVKUA8ODHFMPMjsMxdgBXfoGEEvbTYuL4pOCEDTbuQgLLGAZSuDN9oUd2BipFk22cDKgYPK8XuQsdglbubBsFcGftpGgD0mOMcFYm56BpLoOMGcVkOOIwTDJLocmYbA5rfBWbeu1ZKKxs1W0LsCcKLDN52em5vc(CjfLvjvoOI5GPSHuK3VGkstjb1Gx9Fp3sdkc6VYiAYsYHn4dhzzLswrPKLYnIkytmBvCufCGuGMvwg5kiFCcRi5kjvog9AHe05tkcKsUkgYQ8)NDdbZcQXBsw2kM1GOLUBbP0IKvSIznr(Cz016sqTfzP8zZn)HZYFaJ3QTiKRJLeCLYKty7QY5v0ehsvwsiQAkWAgmEGo3zI2chO9WXudfOJaBpCSH1Kv1dEWyarCJ2h2LUnSxmOQrwzZKkdT2p5knuQql8GtKGxnQTD0)WGnkZTjdFucgKO9P1msG)H2BMOTE6mE4yCQ7oqSyrIgB1Kg4iBKtTRaThiuKoBY4JK65cIkcN6Uc3wKwApmxIUIfjC3XPKxpxSyr3EpH5gju4aXBBNDgz7Tf3IraFBpAl7KRHUchNRHo7QfUyHI1tKqo5C0o3P9ht0DBWGUttopKMLN)ZsQr0yAlg12wgo)Suocl3zrlFxs8jfeLLatiD(Io1DvLa2J75wgHAYmgY3hNOXFdNjxkW3sxwv7byFmsnCb1pOIWGjYdKvxMCdtxj2UWacs(ILeCDu9pssjEnTEPFOzF(8PuXacIzskj0jUM10)ZFdWkhMGPbJ9ogTfbjjwZvu1OcruKGPCXG5a6hc7elUQISY9MOLW4SWqI0fVb5vj7MHzSckis6GyNqYhshEz3zsbHcgwrqnjoj3NGVZQjkVFQ3uN5ZMamcFfyir2jPDshBLeBhKUxojUiPNr6gCjYRzk4MtySYNrDFWI8mPpizpdRrjaV(eildYNSF08LlL4q4NJNjRGkxcQrq7OQrBT12J0z4D4RR5SX1x)1A8QVyBVTODh3vJneO1D6QPbd0slH7kE4q7G2qd(m)FbbhPqUPnuSiDUZiDUDtAXx3sJ(8fR1Wr2EN7WNvFv7kCNHqYk0YGHc3cQKU54rqpk0c1ZigrnTMoi3qIe5Ha65GPbPzb2eJ5f8QjslRMLxVvvJMQVjsN(h1icPTJb5wvwKq60cj1ZmGqVMtsgH7JKoCwf9dgvT18ssIMCPHwbUq0m6AWCY5ei5fhkLGuMSzax2Yzv1eZiiLsRjd6y8XqUvY(jhO8REeKdbsaXhsyDvFmwxToshLqN7RkyNat5EmRbm0CbbsVo525i9mCxyKblJWigUgXWfZezYHykLShJyRucU1e5O(zK8CQPndMqUgoY1AUWN0S9sAY1Xr(KCKTAUMMC9CKTzr2NIJeGJeKJ0Id6DeDGe2SxPlmBPSiRPlrydjCnVgzpWoDgtsfABiDyXz)5e008nSEHwxMFC2FtnUdWm5BaR1ifwxejjmRJEaWq(gy(KZQWcc6f6OkiEsT1EuOBJGZMH4ZcR9GaoDmFspdHHNlWGkbgujmtSNbXq70wxL)AQbL2iylM7NUJeG3KE(mkBksoWgMgcIDZbsLkAoTBoS0a9e5MBrwv4M7qivg(B2Al4BooFU(xVEF8knod6KXM10U1WmOBH6QBSpoSuTlaOJulEG67RHwkj6vWlmk1x3cVeDK7y1MrZf4WHq3R51oYHK0RGxqPk5CsM7f3PSUnVat9Q8FLxPTcPSWyGCpiBlIcaUitMgebVa89OBfMcMqfjGEDJPX)b604rSzr5i0iAFzxRcaWrqTwBVaWXFcJgrQm4W8JXlPiYtdcTfGBx1vzp(kIB68aSsDBU92ZczNrRoyh5)CbwDfxXafy1yb6dc(YU2eWgh9tzYrXbf6xnmpEPG4fiDSaQj2XKKv)4ngiLt9gxbyIh0OBWwmD4dTcZZED1ewDsgbIulzpJyql9JKokLC3LC0crqMpbJ5Y4dcB0nn4elYZv(htkVus5ZJz(GgoKrulO9eIc4w4ZtPcCsTByBKOa0oZGAI2mTwspb7A3n3nQY7g9kUJzTaYEolnQZUb1WqsdBY3d2HaxmnrEfHejZOc7dtNvThpJeqoml62daLq7LSG1h(BQI0je8J5vgPpjqxuWnU18tUD6wlxBJ2VUPg8nkURxiabpsKigcazEnIJHThixMS0lWrI5)(iDVeyt2bbaa0OML4ddWA2k5qLSIzrd4c(hHpaS(lhVeBlau8uY7pNgmIJzfQ9rkz(KRymv0IvNUCDscP1Bac2wceKBrcM90UJRY)sR9vip8uO9KVUdvM835qnjhFk1Vkailc50GnVksbn89w3SqTdvku5OAj5rrDR8uw96cr54MUk3ITmEASxnBbfvRqGeyTXvq(7jp68i7zuEPImufTKFXyuu2a09Oz7aWU1hDISqiTAapyLk1bImOXbjWENrBghdn0iStmnGuTFShRaERAWH9shkdSYUB9dcUL7N0JAOmAkcsouZ5bQ5jgteSFu4TXbWNJ1NkFke1EDI8sPj7rnLzN(mPpRXBLWWHuhFKHc8AWkGGscWPvI1sEv8tDW3xMKa8C5mAGx5VH8uIKhTuuhbvtzjgNJkiGvUFj44JWkrv9K51fHzIrOO7moA401tboTyI8PtRzfIPCFZJA8bn38cGt3Q87F5lhcq(MObc8uGv5GUKWiktjKVoN1QDaZRHqxULqBBB)8dr)Zhd0Cnfl8rPrzT0GtlAiz6b6mB8SwrBIlRSDyHoQlBDRpBHjkbY3PKcbJfs1nAG1iXarTuhdBspNnUjfSMKy5J0(SOJxJqbssgxfm4(SGjiA5raHB6YhG6K(cfZfD00ZegSgwNLh3t2EtN5t2ZygkM1L(mn1GcCGdalUEkzzvr4tkC7QGdTk6McHXaJpVX7IbEmcPCaZDSoYOPbX)ydAnPz5kUNrZACjJRaEMgyDw(YV3koxlFtKKxdoy6kZkaEm0Zha4Os2pNQ5559VIzHBvv4Km1d8CtBIQZXW1hAGN5G8qWv09pioPz4butb7FBB7xCNV7(3WVBlf8a2DbpGXAbpqg7A7GFFYg7ZDCy8CCAeGtqE05pme1eocE7WHUG9RXKW8avo3v(tsTX5E3V(CpztvZ8LEr4FK5EYdunZlDDvp75uD1mVXXRM5jpt1mV1VDUF3R7QQM5j(bNyUZD4h6n(KZ9xip3t)tV3kpNrZotZvZ8xgQAM1dC5Tpn5VtK8ACKFKBRqdulRXm3e4AZxN8g4Q0PXkUcd5m5mhY9cd5EbmkWqEeDyQV)GhepVih5nlL8)gMyEZPwH3zWmMOpE9eglyrD6mlRAg1DmDdhVWyycO0zBnVGelanSFBx4f4CmVj0s81fPlmuwoGQCdy83MzXfXBEJotEe5t8kKvlwidnK1iswRyHKXWrpCFTIwNTNu9JHebuVCrSdirG)UjDqVSOBhgNY3ybPpJy44qOl)GQ6yfjzxgXJUrA8O9q2l5M8tUzCDBJKBbpvTO3tvt(JWCW0ltqCBrOp8KeIKKCKuhLi46qNK0UBOp3ni660WKmUPyFUodmPF7t7sKC8(St5rEjfoMJXzCjkKBTvIAtoojkrhogkzaNhof2kdA6aLZsoO3ZIsUTZXjqHtyEEo(j5oSJibyKjFAGh3jC8sYN5nTpUyHJxE9EovP1bfXtHEEpvPJtNAdyKCxGyhKC3(ihEkoMi5Ek(WHKJyeN8t8jOb7)S0JN0d5El6eGKpNX6DKd33oiFEYxG8fj)X2G8jFPIphf5)i5)eEMPLSehtxdv8jLi)jK735zHSi7pTWMPFHzJI(pZ4Wox5v6Gv)5fD0gYFH7JF4G0)YIp3c5VAQpQc5lx8G(V24ujlzjoi5)sXNfH8aEpec5bH2hEQpTb5Hk(qgKJr(BMh5Ru8Hii)xl(eeK)wYxLJ8FJ8F31jeiFn4A)pSpoaEbBmPtzCZPxOrYiOs8iwa6XDKa0gKhZeu8Lur9)Sy45i(xuwp(mtwItlz9)AYGAt(gGOQQkhUoFZcUd1IttNCkrnl6e1m5BHOLjNYfozYtqEsGjJciHjpfh5P5ipdh5z5iFBoYZbGCRXcKlmk)hm43PNUyyj)JEqVsEEe28KJBfHmojqwxYKdzD5UK1luaNk5fjeug1vNB8OKV7KabLmMBqNKxAgb0K8YfHTK8pb4jjVIi57jsg3bksYRcx77t(NDUtXpOiKIKF40hEifacopyJcI8JPzlXf4hxZtiOp6FOn8kkg0h5FXlqpYBoFYz(9j2oYpH6(ByZ8aPRQZTd4p1fmoYpBAbEJ8wgY5TNXG2i)8IaPr(xDGnJ0OFstIKwTVDlKTBDRwAJIRcryHyRSawTLlVBptICFCM)r8tVtBKRMEl2iRB(K6weztIK1ls2qZKnsQN0aODnHyXkFERQcqllNSzgJ7k2PUb44M0BeZrqiJgdoBiJ0BKKBiJiquUIbIYzzbQv0n1OYvkv3kfvT1lsPd0Wc6gOQBUWDSR32x0HxQHUfVI720SVLPDo0lyoN(zshMtCnTcJLLsVpNT55EM50SVJh4JFEHotrWnPqN9zaBUOBg1smO3e2CmJSi9r4MVKHB(MnXnF50z6sgUzolmEtkW5LSeYNveXn)RkGBM7shUzop4MzCdBM7YdSzUZpSzU3VbBMBQGnZ9EhSzU33bBMB6dB2RS(guz5WnZg3CvNBCZCfJBEWeMpLpUHpJWMr4ZOPCYHp)uxYHpxdNl4Z(qhma3maWfzFHfBtRKE9HByZmwOM9KYWPtg6nUTVA2yMnGyEMhyXxGOLTaaBHAgXE)OZxzz2P0ZZJdMfUn6ZMKdOBayiNq3SFuMwXkjBYaMfGpcqufPWtTZfrA8Ufrd4it(dgJfwecNfoKPfiKSxgbH4bGtsUlb4qqqiqZtxCifWz0rjV3M)UGueixi5VRyqiaSKZpoeJNPJZboe782HOrk(MTpv4qC(mpmJWHCuRhCblCioVXLNhCioFqeM5PVZ4PlyDZYgiYYx(feqK7UealY0eiYxreWICXK)okkeaoIRDSX4CxiyoqWgWEZtza6jbCaUXYfeMdeSX0qwCxyYQOu1HynE05DUevTtooKAMM4qMmWf0jbxasWu8zLppe7Ihai1iotgKfbabbFCAdVJjj)D2aqq(pdUxZgiqq0hooMazsVFYuoF(aIGOvauiVK4fnqKX5aSiVxN)oZBHRlKi1u88unNV82DXNXodShxS5TZdUk6OE646nfzU7rl93d5TBlxE3LftD0s5StDuB0BjlczZmHy1yFlznYLLRSNbi5WSNjAD)BX(aCynI0NJE35KdjAPfs2MDw2u(4fFRJRFJ11qJfH18IgGi9w96nHvfbs8x(rGe)WhiXZBYQCcsKZn2Pl1jRIcHOQ3JswL4LJKv9(bmIiwVlI8sntWiIq9UyYl1mbJiI17cbJ45xufDOMP9949YcgreR30gJOzcKCav88IreH7nZWi6aCikmqMumIn24hcXio53J3Lp53J3A(G094L7d83JxZ7ThMpTcPM7ucoYmN1DqT40ZrVBQ4nyDtIMjMZlOqBeBieohGcVCJp1a050egP7NXqO51k64Hl0j4ua05sT(MUojpTIfmGDvs9nCTRVXUpVj4S3)Qko2srBiAklKGt7B26Li8RNJNtXpc)6hAXVkotXV(rpKIFusoFVjjNEKL4LJKCEr(qkoPay)wK)pNR766V3tY5m5PtCYsYPN726hEbW(rpKIVFaa77lt2Ph8K2pJGMF1vmXtoTt25kCI70BQoFF(xugUPda0p6P97s33sM3Bk)cx0pTFZWVLmxwFA)8ca9dszq93tFlzUu(LnFsrLAcA6s83R9jhvkcL5s)xt9jfvQHOk6j0yMNb1l8VLmo)QGJiqHHLdqLZKmPIaqXbtnNNVLmNw8cnbQLsXHIYyYZG6hE)wYS8lqaOVF5UT7jdQ23T9Q(GZDBFs)wY48RtXK8TK5Y52ZtskDNgFlz69RHzIevtRVMmMjX8UhulxgffbDTfZSAv(86YQ5ZXfmPCkHdmN)O6QJ16YSj5ZXMqGnnwHWy51zf11v0AEdBOVm6I5tS(KYz3GqUucQ5e6xEdy9qBd6QccBilVMUG6gwVfFkd4zEnb2vUbqqSiDHcEtRX6QR5wUPnElBnxgj2ycsY8P6jYARDLS6YSQcAc6S6Iz0S0OYqoL0SOFWQH1Fdq5uzXVP7BGwTezTl8BSRDL7kCS4rAjq7RCDSRSfSs1TYAlRLWT3EVTenA7HIU7o7T747P9WSB16YubGfisw586SyPOJ1OyHXMjnROcRz5(I96zxRrfYQz2nwx9MmT1aHc3B0EI3lwF)I3wVDfogw63aUddokN5tLIvlF2Si)WcKaokDuBQSvESo9iljWNBDGvqNhSny1UWuoD3thDeTZEJ0s0o7U3WDgiy7HdbcjnVKMqzw2ARQVi7(XQjhlpmbAuNEOgmJIAMd5zOows1uqXc3s8aDU9EApqSEBPNUJhTJEJ0ziWGgpAmdXxKy7beBoSQCXNvqJnTkiGquLx7kznkMwSDiaogogCDcKhNVV6QF9BKvktcvEvRbzNrAzNXdS9jD8PkKvEabwSyGaJt98kSPmKJHq1ffynldMSYPPFKwnrmNjDniJdUcXJ0fmy7i6Uc3BSarc1B3HJ3tx9gkC8arAV4XOrHnHTq1hR5ICsqRCgALHYW7WuebJglu4y92DK9IUA1Bmh5OBMmLwI5yx7TRUo2(whBI1XYFO1X61nZKBTeT9OXa2D7BCDSg)x9hIYzSqDyyBGvmSWcfG14ucD9aTapIlh6mqh4)h8mT8QAl6U7D7XIcd8UchVxyXbieKkh(VOJv7zsGhCTf5SzDmrMtoxDgEQMSRNUd3B7rcIlfAjAhDyzenl1nfksnLnwsjWu2ceXitU(0ALSTJ80lOz)XWY1y9jmQrkgFQHH1L7RpjSyJMV5HWwQJxspwmALZzUNDdN1OOSAuYvaETRNEbdccJwUptarQGfDJZ8F4elaE5y4lVZEPV0SFYVBCMz5FCgMXzMDZJZ4BCM5aSBCMsNQlDSfmvx5et5vgcRGRuLGtzrAz5v1JjOLxvvGwnxanHCDh5U8xuNhNPKDDxWvanbE9qW)Ut4F3)EPV4M0slUHd5(6ZL7oD308qPEnh5W71RyF5fuqUVb1wHVCyuYV8cops(nwGxr)olysLD4JKAHUSxJqNx1eZKwpgy4o8HqTj1cbQ1Xxo8clOxH2l9ZES3Lz2TsNIReAVtzxMlN(uZpuJpRrDuPGZ7YMl7rgZWHoMWTMxqtNcz85ltvptwbyhKQgf2dtbISkGLaNg4LKaWmXGHxoH9bhRgbOUz401vqZRsjJGf)tZ6v2TvEa40E(8fa2(UYvahOzNbXRci)hXUuNPTAqPklHrW8YuwysrSA8kj3N2UYiSFHuJQ2qJxdSSucRLuXWqIAPNibVUUKa49rl2NnZjwgz2IJKsGxxmMGISQUFXQgbhMXX6nJG6oej)9bklg4Y2V2oeftKqwxSxXYgLw29cKlvx5LK2Hiv371iEMFYVAbG2uyZLUufga0NvhtljVKqjQMfujUrPlDnTCia(Xz(yvnoZFiazmb9sA(pcAVuYCabPBJE4x0wrp(0IWKG)wQuYIKAURP9HYOfeRURrYXLa1EAJd2VWb3peCvBcJQFzKCPZRHf5R3Q6zxHpAr8QfmOlL3OSgNzv32oya7UlbnoZNyU36)64mRMBCM1qF3AhksoiY6aWwSuUPmoJFApHL3I8Qc0A)N5K5(cMamVBboabCEXZ2FoiMSr1KkkSPo3yjP1UW0Hpa4sPXnMQGI0bTQSzCklmnaPY6J0oq((lZ)CREa)LhOztpOHSQCCgEeJZuzzkLxCLVclrw7lwxOPCYWsxy0QuPSHs3QQJcFBZKJVIfVU)WH5buyaSICjfU3vOuLfLY50XsYC00PHDJzsOPdap4t0r4qr6PJZILMjh2IDPuzkZ6Th10BvEMpRvRHesMjlVeZq8wLFVy5egqqTabXq0O9Oiorr8rRzmpC4ejDXeM0Qsvt0xaAHCeBjHrHf0phUUIA3gXQeCr9aABBV03RSTQ8qVAH3WmmT2e2Ir9bM(EZYal29Ty)YqPZJ1IoKmr61AW(fWkvOAigdhhAcTMrssCy7MnujFJMGxTqjhmr3zLHfAQ6gLQtLk6qqnDMCwOfdYRYw)4mS(gsswtZq0WSoCe8F2wv(BN1SMvBB7F5K)4Mw5DU7cV5Suv3UcQUpmhLgNuElmgJiW2bEbB00ZGBqqHCY6V9sO)122E67h)7pTWBSl0DOBGVjWI1kSOhw(t9D4elyYNiRmSrio0Tw3rBVXrGw3o4VHUsC0XuHjURzyASPcM3saY3CJmmJWNeHIB0oMf72223Dr18hS5N8RsLKsv2fp3i5WAnoLsrLkCzhAhe253wmSn38ddh78l4dTs2k7zHO(rthdJdhWQgIU5ghorM(mlBDLnCHkPO9I1ePL4hqwnwwmca5fV3QE6kwnHz1vZCCTMIrbh6Biyjuk6AXLrU9HmRfyrcjwnZVR2MgNHRKXz4HRmotcX5C1nvnZOzXwl1UvOjExecnDtyt(SBkuLTUQ1V4Qz(EN21f0RduNVFcxTcn1NlMsyoA1mJ1m268Cq4SN929i9xDzytv4SPxMfBArfr1kWMMVZMgFFEgC)W)eSPpwrQwhE02F4rWMwGDtXVAyW(Y3JlcF5kgivDnv9SNZGEKZZFs3dJzpNpTBBL)JunZZMWJA)BFfpMGN9A9iHNTdx6i0uxESkpZz8mE))DtEgV)0f7AEGW0A1mV4Q9q43(t7EcJ55(TEuTx9l7Aae3)UG(wNx21QNb)Z53d7EUBXJ940)Cx6X74hu4)XN3tFFHA803VdRNXW3z)UuTJ5hwB8dxJhf(zEsVtnn5sOvE1PbDEJEj8j3f5H375CxvKqBroiwyAreHKBhwx4zSn7ztCp3o7z)cEnOVGRH7DUycd4nF)pFX(pC3LZ2Vs72VNPO9ph0oyLUX)np(H3OShNoJEBRyCFXftJCz0(YDsk7BvSzN7DkFx3)AbAFKFPN5Jt0VNWkaHJ(2EiC0)zxegYpmMgw1fHBgB9bFuxT(oRfA9HMJ7LVv06CQfUW34x76cegWb4BUmp(IFZt5zY5DoMh3KtEtEmEVZpXJh73yfUe6BG64JFDUJtxlyoo596XCCY4UK7HRyxVHFG2HJ6H2HFcp2yiU1B)qE08h)t7rZFWJ7XRDwFvpbPE8(8m(EQg9Ohp(D4X89upSlFVkXjeYXD13kPZ1h2D0BmKXdUtpY5S3ONr2dEaptM)2VOlDEovURuRhwp8AFgp0(A)fE44p6UDj34Rdcr(w71J28U3UNr93RrpS77UEpwWx2LPN7eymT36t5PVN4N5rONoJRXW9xhyb)r)kpo6f4yrJ33669iK)9wC137VIMENkbM(xFxUUWQQfNw2JhomCApdXhC7E08x8pWL2q3j7b(YEi8HRZJA)eAEe6dxHlHwzLTEmelWlD4jZw8Q8Eykz)Ey6RCw3dzKJKhX9A31bC8LVppC8FIZdhF9sD13uliToUu4Kd42SxBzeMbGX6J7kEmeE1RFWjECp28tTbpk0jEgpR7p1w9OJpXxZ1A1JHXMg9OEe6J8JlUVCpnU89XDhLDZy3pXc829)nxI(UDU)L9onCFwNTxLD7F(v7OD74uC)cOXpfDBegBM)LCYKATj(yvoqLRhuWF217rb)bUHZCyKWjI5HWF0NZfH3)6ar9AVK7ihy3)bl1RCiU6U(6H9LE9RZt8Kx)l4zY6mh3d7otgpZY)0xWJ7XzoL7ihO29A6Ey3R95MSDU)XR58BfEJYbBoeS8b(Z94jEkDpdUV13XJo(an4ripysxcrzHg)exfiVUC37pJEsXDrUMYcI)QD0ePHJmkM48EnRc3KFtm6pmuKFDq83xQG4V7fjqcAOrYVH(M63iqdp(lyf5xBMznJFpDQhOOOg28gj)cYgpY4mPj)MXz6J8RhNbqeMzCM9HFUF8fjSXS47Yr()sQNs77I0(U20(UiTVls7sqAFxdAdxg56kJSTYmtqjcTKEA3bMDtLRspxA59XuEcgYtB(5MkVp6PKX2EMMkpHJ2AOCvFKN1MoOF(iph8zgJR3e2NVT51BOqB(G4Hfjl0qRPVlbvmHB0FEowR4TgLnbMmqnHXzwS7mu1oE7agmDgvn9y5Zj())'
    elseif MUI:GetProfileResolution() == 'FULL_HD' then
        profileString = '!CELL:258:ALL!T33c4Xr1vA6YT1QxtIFijS8ROcd2y1yzBjBjIf4aDRULvBlPwtR2cqaJQQ7UAvLvPUkQQAzBahazJdHjzYUAy8oZojzXcs2KDZYmiSzdtWbqqCacjCJWdOKjzji8ajbYWe)5z28LVDYSNZTQQ7QRsYs(vESG(WnDFFCoN75EUN7)9CR(0m3)k16xiJGgV8j0sZNsiAwdo1kfLsjexrr2qsvpsMwugmbVb34dkKjBxk6sgskzg1qrTVekggkdoLqg(eY5ApN6I5L3d)(03LAkEdHaz141fvxKHv12eO3rdgnE8OD0E4wJRfsinFwzdT4r7c)mtnQlgfHGYs3XDWRLQlEnJ9XnrAn(bf6stsrtYyFn7pyh8sz48ps3QkgYs9lAi6F8)4SsjhGnGUUKUHyczLKdiKsuTYS6cTilKTnbEzdrt5sdKjN8igVukUHn04ZOllziovYS6WylUWEnYQjOxMMm)(uYAOpK6krQiO1ml2J63uDn0i7DDxSTMvwMTTqhQHmQjFc1Q0bjnGgqS(faTMraDQSoSUkFsPm9FZfpSUGkVgigI2LDtfpgmUG2YJANHhsqZqkjVSMPYnL4uij7w6oeSOvc(mjfv0iLpSQLgTSruv2JGg2MIcQdV6)(UTgufmETX0vKvcBrhYYlMSYIjlJBmnq(TlDCvufNRnRUmYQiFmclh5YjLpbTUqcg8jfXkVIIixjq6GdcIXBtw(kN3WOESBb50IKvUY5nv2msg6DjO1IIC2bZu(OdYVxZ3QVyYQgfKzP7qbgMYtKeSRKYiSDnLSQ6IJOPilevlfOAdgpqN7mrBHd0E4yAHc0rGTho2O6kAgb3xmOrIJ3p2LUnvCmOmswDZjmTNEVp6zQGCfmGi(IctLGxlAELQFYgGbkQJAvsgSa0F7eTTRoJhogN2ngiwSirJTwYM5i1Zflw0TVRWCbrgZP1t42I0s7H5s0vSiH7ooTnnWLO72abRtRpnwOWbI32o7mY2BlUfrqA2E0w2jxdDfooxdD2vlCXcfBxrc1Kz9qVc2r0o3z(pQ1vG2deksN5lzeDBB7tqQXAQlgv)w2PrLExY8jfevKbLMimLIZBMZz0PpRjQXOAlZH8dWH)jkkoQuMuG9LHIM(dX(eKA4cASpvHHtKfAwDszgLUwRDHHeK9fljy(O5FSKY8669r)qZ(85tTIHeeLskl0jUQ0Yg0FdWsyMGPHj4DmElcWAcRL2Rsd8SidZ2IbZaTFeStS4QlYQ7nrlHXzHrePlpdYRrUjgMjYjGythg7e28rmGxUrPuWI9rvf0sIZT9l01c20gUMgpTUOYEOwtDMDWeGk5ldJls7KoiDUns37GeFPKDjs6zSUbZHS6wCVzstmbLfsBq6DuDAfy5tHKkiFYbqDxMuIJGFoU0GcACjOAa9dRfT1wBpsNH3HpK71VvZx9fB7TfT74UkSHaTUtxfnCGwAjCxXdhAh0cAWN1)liyjfYDBdflsN7msNB3QTMdxF(I1A4iBVZD4ZUVADfUZqyZYvYWHc3ckKUP4HqZjuZ0ZyMofTNliXsKil4vpdmhippqNyoPG1MiTI2G8gTQzwu9nrI6FCt3K5Tki3U6IfsNwiPH0qc9zndz6nps6WdQASVOAOVsrlQ0qRavi6MDnygLmcKSIJKsqwAqjWEDjSA6IscYP0BYSDm(yi3ozpK9UKREmKcbsa(fsyxRpg7ARJ0zr058Qc2jquUNWEadfNJH06j3jhPNr7cDlyRegZ0vsmC1mrHSFMIj9A6CL2GBprgQ9fjlNwAlpjKTYrA2ALp5A5ixhhzBCKpHL7bY1B)MBWUnb4ib5iTWrC4pGe2X7Bn)7tNB2sDX2txIWUs4kFDsVWgzMts5kBedyL5aze019nQrUsxUFC2FZnUdqn5Bi71g5wpejjmRJwaWqogZ1nVCliOv0zvGZKAQ5Wq3gdNndXpiSWtJJ0z5KEgbDlNJaLdeOCyMO3Hrx60sVs)Ryfi3gdlXAt1DKaSMmYkPU5izaDyAWv2TgivQOz0V1WYdTRi3AlkAc3AhcPK4Vv79HV148zgydg9ZR245qNm3XM2Tgoh6wOU6g7Jdnv7caejTchO((8OMsMwdwX4uBDBqt0rUJvBMfNJc7hnVkTDKcjP1GvOwLsgzRnJ7uXipTav9v6)YV88cK6IIb8DFSTikaWESiAqecfq3dxfmfmLg2aA9MtJViLehkpjwcIJH2x21PcOCe0QnVvay4pLzHyRmPq5X4Lvf5PoHUgGARAv5hFfqndEaBPrEQ9EZdjNzPoih5)IdsLFSnrG(bNVSRlbSRXa1wGD1O8yvbXkiDUqOFlDPoMKS7hV5aPuAVwjOIh2SBW(lD6d6uTLMFD1u2DsbbGulP3XmBl9JKolMCGIoCopiLtIcEyz8bUn6M6CIfP5Q)ZiLwmP0szkhKWrm9AbLNqua3)Uu1kWj1UHTrIcy7SCQjMNO1s6jyx3yZDJI8nHwf318wiP3tt96CJGyyYPrTO7(6qGlMUiVQqIKsAWMW44P28JNXcOeMfn7basO(srW(dFPQirbNFmV2y9ldYIkURTUFYDs3AzRnM)1n3GVXXD9cba4XgjIUaqIxJ4ey5bYiniTcos3(FaZnxhg29N61SiFOdwRsj7VOvopQdxW(i8EH1Fz4LzBboqqkL9KrhgXXSD1(4fbqxMqd1y1zOuhUVCdGZ2IaNClwWQN574v6Fz1(AKhDgKEYFJdrM836qmjp2mkFva4veYOdBEvGasomUGA9ZdLouOqHJkLKJHY2ssz3RZhHJBUkCxMTYtN9QzZjO65CKaRnwf5RtowPKEhNxUafvn14yr6LHErzdq3JMTda4w)0jYCRXQfSGvR0aAKzBC0eyVZUAghdn0iStm1HuTFKNihoRAWH9Ygrcwz3TX(aZY9q6rlKKUQGSdXSuqmp6eIG(JITnoG8CI(14tHi1RtKxonPxTuwD6EsFAZ3kJUdPg(ibf41HvaaWnHuCXAjRg(Po47xkjatxrshSk)xjpNi5yfJYiiAQl18GubbeZdidNoewjQzKmRHimtmgfDN5buNRwkWzwtKnDADBxmL6RuQYhKCRka19v6h8(7)kUI3gvqhZhUkhKLeMEzkI83WzVA)MapTfY02U(FX(P)5JbkEffY8XPEzTLGxs0KZ0t0zv4PT92exrD7WcDuwQV(tKBIsG8DlkNZyHuDJkyDs3aRwMJHnPNth3QfSwnX2gP95rhVMUcKLnRvehKONO8(1QbD30Lpa1j9fkMRAO4WNYK0W6SS4EY530PCsVtyky2vDpn1GkCAdalUrkffnr4tQC9KZLVgAMcUXaLpV57IbwmcPCaZDIoK01b)FSbTN0Snf7D8bnRYSgWY0eRZkwX9xXzB5BIK86Wbsx9GcGfd98baoQKdWPzDGE)RCE4wv5ogt9anxZAOYCmC9Hoyzomp4Cfn)dItAMwaROqZo6hVPCZ8t0cEkm211b)Uvm3F7XGXXJrx5F0yi50FOklz1)0uBQKd8wLC8MQM5Z9kW)iLC89wnZRETvp)fuD1mN6XQM5zFNQzE3FtjF)R9kQM5z(rhTKsg9Hp11vY7RuYl9Zgf84cNFVD40ALtow53FLNvVyVDZvZ8xhQAMnae99EjYFRi5n4i)e3J(gGrFvvzoJnfUM8TiNI8)gvE0bDvN11A5g0szSg0nbd6MG1mWGEmdysFGG7dpMih5DkgwZ)2ZSa3EqjluhVvcZfQOm92lVAgTDmxDdVOyyCLmyBnRGmlajCG8MUl05yEZO65n4OliuxoGMCJOF3MzPHZYzqJi708m4MRy8z6Kf51FSFGM0LmRIUKHCJMomUz8eYKEj3c5prKCR(j3Mp3h1DfMTVpZd4QTB4yAsP3h0fEscrsQdteCDIqsA3fmO7ceDDuvIK7wSBxhqLmq(JIsKD8((D3ZKC5xRsYDmeZZGsuj3EReTMCCsrIbCmrYqop8i9yFSyX7Z7zfj3X0CcXCh)RZIMLJhsUR8EmamSKpjqJ7go(h5EE78NOl3X)YDypxhc0Xj6WJlgGE8VGZ8jaVwhh8JCVaBhMCWcodh5aoogh5(k8WBKdz6hJ6mMZg5ApK7VaO0Kpn5b2b5pL8ziFwYFg5tjsHk4GOFU8NZ5RHe9)i5)eNl4eKrk8KmK)CYdonNvH8xKdh12qg)F28Si1wB(ZIq(ll4KhK)QcpDWvCfoy6FDHhRG85N5tsq(c54mDi)fnp0qvv5Oj)xl8OcKhY7zeihbkFu4KaW5bMUddqE4cpda5riFzrYxQ0cW4t(VviaFYxH8v5i)3j)pCbGN81G6(FAcvhWS)Ayf5Hm2l5jMJoRiJH87XTHwdBUbawNrVJMywDXQNCUYQ)xfcugrIo78IRaE9nMR86VBAa9EwyvbwzpvoB6AWPPJp7GAVN0KNJJ88CKVfh5eCKVnh5f4OkZEipTtSeFtWZYZqEwGOJtbc7adkmkFrru12l5LNRdYVJn0ohymrjQqyLfHgwausaqNPs8vCbKOqOK14IjFpNyqrMb8KG(bASrxWfXk9IqKmrbyc7L89rqGVQ4Cghi5Kfa9J83dW9iVMizsoYRlMhKh5ha19dj)doa1r(rfaKJ8JN7O3mXEaZd5bRqEtOFBEZUWOqvL1u48unfIjJ8p6chg5TVGXGrENlqOxKFQzq3MjexZIP3pZfklYpFoGTI8UM859oNXur(ffGHI8p5a6ezhpaEJf4Fe)0lCck(OFuf8YMiRVCsDlgb5u(jx2TwjzJIKn1mPEsdKntVgKgzO3eYw4WRe6QfjB)e41KyEfyTvgEFjreDCvxOLL1TMq(4xA3ANCn41rrQ(jSUyNviIYekdGaYYrfkq8SLM18AK1YL7U7WrZ6GMjs7qTI2T(QWvDhyBWPlPx6YHC3nO(1LJ61A2BhmXLWGnYuyC1UD(qFSzbUAnMWM8axLIvfaT69MzOT3cUAmZqRybwnj3CdVA)xcXRo4mE)jN3GvHIq8QZvWQ2xNbOOopaREBwGv36CWw(AVGVLclWQhWNl8QZoy11SMzbSkgRxeMkaA9xAcAD2bRU0LEEcw1CxrhGvDg48zbSQZOIFUdwn)q(l6nc3NdGvNXixpnGv)sLc4vp3aRYvay1CHwUquDZ4(fNpiyrKVhRi6ostdaYluwvicwe67XmH9mnaJVq51FNlE9nCYRPfTAvZr0QiYtY3C4ewpzlUbPIGtrqQOoC6a26b0kswhiqpxaVIGDXX00hl08GwHMoxOzbyvrGUiTPGvRRo3X2eWHoRGvXU)QNtbTCMaR(6iE1F7awLXgRQh0DZLWwBExO65rSwSfI1l78eXQn8ZcrUAbVz75FUvq8wrC8uQGOlqCfoWBDPC3jefP1FuuKfJWbbPcaqcGg3IicJmh0rkCkajs7l(GlZghj9zkkEfhqDzoFaW2YMCfiVAMfKrR4ShiptKiF5CwItx08iCFyC8(GxC8OqJeNJXXZ85oyO8S9Ia0irpqJ(mZ3n2iXlnyJeNDSrIFyG8(DBG8eDhipXlfbYRQQCy68ufCJ1NfOrIN1a5HrT7SGr63AbYZ3meiVz4oHplGJykiqERznFamqE1uZ0boAfNJbYdaYaWzUWdN3CmQzIxyrn7N6kQzoX7qJA2lUTcdAwt0Nw6PnOzBaXe9)he0mrhbnRiY6eDe2lRHanOz33TPwTnUoV3p70ggnBkKliCueIhyBO4zQVYhgnqCNUWOD(ERVZuy0wwH4e)N)WqODXleA390ecTlDpOVN)HqZ6(E)uIZye0mFuCDGxC2dHMZNH1lS77DnR5pWUV3lXHqtCgcH2fZNQXzjeAxuz1SecTlMppKfIDKgbTsTy1f499AgbnVWcrDM997olHodP0lsXeFXo0zfz9yeIi5a0I2HoZ519EpLD)QmRB2VU3ccH2w36hycHwEyIBCJxmUV3lwWeVOFFVhR4lKB7f1z)o4(EplHoKnhSRZsOdVyVR80Cb0xTOdG0BHRai0wbpS8tTQNQQccE4r)OkQRi)Jb40e(W5kYrxaBr8OU(sBsXJA16PtMra(ofAaSFJ43KYsrrV0sp5Imf5JSnRzJlqG9NDDnmH5A2ggeW4kcDq56RZOZd2CHHG2eYQjm65u4w)qy0x8GrFP0A6I2nrlIrs9Cbg9hgU1FFdh9f17SDwUkAX)q(QONwC0xGHB98hhDnx0Vc6NBM(644ch95t0wlahDT1(bqC0tF4w)dvC043ufXPdhDvxQXrlEXdhT6hRqSMEYvj5Jl8rUzhqdbCGfgrylmHNArikre4OzyH3rUKjXf(3FLCx790KVg(WR9(dYx7Tzkh4C4AVx2YUe(ebEy7Vx9)b7te4VpCR3ONXlaexNl3enUT6fcIRZLV(kNd8YlIRZkRk4RB1Cgg2LKV(kNddYVJtiBimSxsC2V1B6DtFw(6RSkp4WOy8EfNH1KmTFBN)G7TE)HWW(Dz4mVuFN4UUEEwACZCCf3oUEEZy5nTxlE(Wg687sI3VuiZ0LTRUOCFVN7styijH9S2y6j5LfksZkfbWPUOKIygXtwPF9EGgiKACTgA8JxNMGmMohMiPSuYbAHx3qkt)6TsUHd98lSz)XW8sw9jmZhaMFQHrnu6VFzmZ6LT5rWsQJx2iwmAwIOKtVXtBM)bntVaaT655x4WPK0P52UejvgCqLmtY8F4OleE5rWxotV0xA2p5FFsM55FsgMjzMFZtY4BsMfaKBsMINPQEKfot1mcMYbPSI7OZyJuxS(G8AgXe0ZQPjqZCbGKqUUdDV(lOhtYuup3ludijWR7h(3Dd)7b7L(I7MwCHfSF31xc3D7UOsrUU1dDWE9Y2tUWC89uuDf(YbroFYfolC(ul0lRpZcNwEF9hk1ICPKgJoVQlkL2igOTo4(rPj1IGwBGVCWfLtUc1l9ZEuYLz1TINHAc17m2Ls4mMz6Hs8PnZDa5YMinxc7Hk5nVZsEZ7AcZSvsmHBpRGUb1z)lxMMH0GckznQACnbDvLm6cysFObEzzWDumyqMry3aKyCRLTaiJRaFtJfngMR7SYqp3Xsca4085laS8R8vc4tApiwlSV(W6zKuvfm0VmM1QXNfw)LndxWKkPe27c(tQRow7QztYNHnHaBAmH2XYBWkAyOQ38g3y)sgIztSbyHXgfYKsqlJWakBeZDFB0qtqyJdclif024gSPtzanbJB2vVrGrSy7cf8wUk7AVQB7w20TTTmsYSXG158P2vK1v7QznuyHbUGbRHOKUTevgsPKw5OgwDmDXacNglMGg2in3DYMpjfYUUv3t4yXJ0sG2x96zxDlyMvC11wwlHBV9(AjA02df9g7SVUJFZThMDB2vtzaMutzbvplM2eznZTDSsPzfvzTYoDSFc21zMq3AMDt1vVfrBnqOW9fDxX7dtdLXBRVUchdttHa1HbhLY8PsXQNfxItfzDCu6ivQLx4X0kLc4IlZ6bTGbpOBWKZIfF6ExD0r0o7lslr7S7(c3zGGThoeWK08Y6cLzRRTZwOS7bZ8HS8WeOzALIQWmZbFo4NP4yZvlgflClXd0523v7bI1xl7Q74r7OViDgcuOXJgZK9fW2DbSndMe54huqNnTgWGquHx)YznZ9BSDiaggogCDcnpoF)1v)g2eRSucnEn7bzNrAzNXdS9PD8PjmOYqcSyURbgNgzvztzYhtMAikWAL7yzvst)in53ynt6AqghmfIhPlyW2r0Ec3xSarc1x3HJVRU6lu44bI0EHJrZ8WdBUKLxZfyKGAzjAImZ06WIfbJglu4y91DKErtT6nNJC0nlIsZiISR7o1wpB)RNnX6z53)6z9AMzrTwI2E0ya5UZnTEwZ)R(9tPmU3PPUbwXWcluasJtj01d08skUCOZaDG)FWY02QQTO3yFBpwuyG3v449bloaMGTYH9lAy1Uuc8PEd3PYXezgLm1zAPArUD1D4(ApsqCPqlr7OdBL440DCTC1HyLNK5Ju1KmFuaNvcAv6(pe6GtvAVcY3b9CMOZn6jvwmc3)D1OnlsQsUQ2hrspiM9rJKHlb6BLw4WdiSV9aku9PmtqJrYKoRoMhQE3QNFf(O5zQwqfnL2iVMKzz3XoyahLUy0KmlVKB)FAsMvWnjZkPVBvJejdOnhcwwrPM6Km1q7jSRSiVMan90z59D3btiWBCnawD48ANEGmW8GzcpkkSqMBIK00Rx6W7f2jqNBcnbv59zN8TaupPb3O2FK2HyObTE6PsWByilaB)tZSOnZjwgz(IJLcyLymbvfnd)IvngQlIJP4gbTDis(6bklgGzya9DikMiHIHyFILnonh)fitQUYklVdr62g9zAn6N8lxyzJLp9VPVwyZRYsy6XOmRmRvUDXkJ8dxU)sQEi)ljqZw7fnIDwxZSNtYSPYuxsHznkm9sT7yDHZXthU6CtdQvQyQnBvZrgJTzst12vr1)X36gAyuEyBbWpxMKc3)kvRYU1kzmWCAC00Pb3dmj0napH8j6iCOi7QJtJz8ihtu9OwzkR8vh1UWoJgFA7sdjKuAqEzMr4TtFDXYimKGwUged3ECxQItvaD0BgdhhALr3AgdFvXAj6panriILKWmX85Nd3LMQ7gZofwrnpB76F1xVSTP(W)GCVHrZWmrtQwrhcAPLYyV5rqEn26pnSLv00Xq4YbSZ2IBPrqPKl5bgdfBDHwLKLfhnFXMsGVXtWRLld9LO7bvatLrPjtWwmZMV03BL3wr59AY)c5x7BezfDDZwct5WrW)5Bt9RmV5nV2U()XJ)MnT67(gZ9Mttjr(up6UXyuAEu5RHXKYGsdK(nzzwWnmiAoj93EP0)A76F(he)7Vi3BYNH4W5FFtHz5u4SfWUCudhoXC66Pgub8MHkbBVb0YBCmO0TdgBOnehDmLBg7JpkDDMPGi2CxfbnFlnYWmgFseuGz5yySB76)(lUM)OT8SFvkNuRkFwNnsgmlDtBPOAfU0dTdmB21fJMNA(HHt(am4d1s5f2rsNfZNFwYkusd5Fz0es9BL13kB0CjIW8RxtKwMFifTydIENiVY9x1ZxXAjmRTAMhtVPy0nR8ncSckfD54Yj35iwjuRiHeRM5FV2MMKHROjz4HAMKjH4cU6MQMzCExLcfniwuXfu0TGf5lFrHQS14x9LvnZjVpxvyuhio)WeUkfkQFx85k3a09x)LC1qcZHRMzIMXsl1r3N)83UhX8hSCSOkCw0jzXIwCbTALyrL7SOj3TNX3p(phl6JuGa3HNXWp(qyrlmFrNSIHsvxtvp)fmShk(Yh3Tap)f8jDRR8FOQzorhUiA1m)MxZZG9eB1dh(zxMBTeZ)2T4rM)wVJNr2j6YJw6ejCPLimTc6UVGh54vwRho8T)KEKJx434sAR8QtdLUjVdRNThYJ27zDVgSH5z5WyQofpXf5obJIx2Js5f(EEnD(EUTaM)8jUukNXpmC)oEj33RgpI83DpE0aFxwxm9r8dRS(XxL3jJN1RgOjxmnU)EaDADEvZT6Xq(f87D8FBE4Wl9lCjD39LryG1Ep4lxOHh396S8lpF533mu(NgkhgN30V2Jb8nP4XOZS35fFUp7Lr9Czw(kC2u23TWbp3zwspp46G2(4)ZE0khDaxJxkrh)980WX)hC1Wq(HX0OAUA4wWspYXCv6zwhu6dVa3lFRO1fuluX34FXTZXAbz443Vhz44X9iSWYINA5EMfFQN2ZC9zEeptSh)w8OLpZp1ZAXVXkDjhNchmp516Q0dwrpNYpi2Jg1Jyp6Z4rSb)wV3d7rGEYpPhb6ipM7b38N3x1J7NNSFpI9Z1Oh545EupgAp5D5srvjoHqEmx9Ts6C9bDv6jXf9hzNE4ZPVjpJSFZN1JaEK96AKTGk7j1gG1dVX94z(8n(R8qXFYbCX34Rhw3)U96rA(v3PhBHxVrpK77Vbpc4jDP65ok6v6DVbp99O)Cpm9LKCngEW6an4p5x6z36CuSGX77(j8WK)VT4QVpyfnDMkbI(fVxxvCL1ctlJM2Z45v(J8WNJCZE4Zr2Uhzei3d9f8meF068qUNr3d5E0kCjhvwzRpcc85vDBnfA9GU4KpGhI(3Z5HOVvXtNE8hW7PVK94PVV2PDRUqPH84Ukn1ctBGlfo(qUv71wgHziyS(KU8hdUx9AhC0N0Z0WtVrpI5r)wEw3)mFnpRvF6T5AW8iOBYXpShM(4VzHnK75XLVpPBVSBb7(rxO3U)RDXNd4C)R870W9PCwEv5l)pDTokpVFkU3hk8gOBJWKN4FoNeP28n(ulbQawr)q)LEuxpTHNv0FZVRh98d1GNr2rs6wdw5q097EtVqn(jFAxT9GBaA4uXM9gwj2WF(NWtd)rUHwehB4pAzEBiXvdn2aSn3BDTEg1V1NXJ5978yEi37i5X66N5bLhZ780U9yHs3By4HCVH7X7dUEy(7nEvxnuDrM)mrfiRHs37rYiPypKTwwq8h9IMiB(qJJbYRpRKyn5xfJ(dRe59dI)(mfe)zJiHg950I8ROVPHgH2WJ)cqrEFRyfz(Zrt9qffuWw2e5)dP(dnjtAYVAsM(jV)Kma8xPjz2n(5bWxKXcheFxgOTnqB7sX2U08TDPyBxk22)vSTlfB7)c56lJCDLrUHYSUZdehn9KOdn)MwIg90PlPFMLKGH88wFUPL0p9SYyzFRMwschL1Ws08ror(2b9Zh5fGpZywFtyF(2w13qUY8b(0kGxOIw3OhbnmyG0FDlwN4ThLnbEZJ6cK)n3XOQDm6wdNwst3iw2mI))('
    end

    local profileName = 'MerfinUI (' .. addonTable.ScreenHeight .. ') v' .. addonTable.Version

    MUI:ApplyCellColorTheme('DARK')
    Cell.ImportProfile(profileString, profileName)
    LoadCellDebuffs()
end

function MUI:ImportRaidFrames(frames)

    if frames == 'Cell' then
        ImportCell()
        ElvUiFramesVisibility(false)
        E:UpdateUnitFrames()
        addonTable:PluginInstallStepComplete("Cell")
    elseif frames == 'ElvUI' then
        DisableAddOn('Cell')
        ElvUiFramesVisibility(true)
        E:UpdateUnitFrames()
        addonTable:PluginInstallStepComplete("ElvUI")
    end
end