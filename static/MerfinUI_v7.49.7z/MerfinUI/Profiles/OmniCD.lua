local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)

function MUI:ImportOmniCD(layout)

    if not E:IsAddOnEnabled("OmniCD") then
        DEFAULT_CHAT_FRAME:AddMessage("|cffbefc03MerfinUI:|r You need to enable OmniCD to apply profile settings!")
        return
    end

    local layout = (layout == 'Healer' and 'Healer-V') or layout

    local profileName = 'MerfinUI (' .. layout .. ') (' .. addonTable.ScreenHeight .. ') v' .. addonTable.Version

    if E.Retail then
        OmniCDDB["cooldowns"] = {
            [114051] = {
                ["type"] = "offensive",
                ["buff"] = 114051,
                ["class"] = "SHAMAN",
                ["name"] = "Ascendance",
                ["charges"] = {
                    ["default"] = 1
                },
                ["spec"] = {114051},
                ["duration"] = {
                    ["default"] = 120
                },
                ["icon"] = 135791,
                ["spellID"] = 114051
            }
        }
    end
    if layout == 'DPS/Tank' then
        OmniCDDB["profiles"][profileName] = 
        MUI:GetProfileResolution() == 'FULL_HD' and {
            ["Party"] = {
                ["party"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["columns"] = 1,
                            ["scale"] = 1.1,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 346.7560630839853,
                                    ["x"] = 202.5780430997475
                                }
                            }
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["scale"] = 0.79,
                            ["locked"] = true,
                            ["growUpward"] = true,
                            ["columns"] = 10,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 180,
                            ["hideSpark"] = true,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 531.4668965497003,
                                    ["x"] = 360.9774826991816
                                }
                            },
                            ["scale"] = 0.65
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["columns"] = 2,
                            ["scale"] = 1.1,
                            ["sortBy"] = 10,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 543.7142058740392,
                                    ["x"] = 297.707863111591
                                }
                            }
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["167105"] = false,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["179057"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["401150"] = false,
                        ["386997"] = false,
                        ["51533"] = false,
                        ["102558"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["152279"] = false,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["123904"] = false,
                        ["360952"] = false,
                        ["110959"] = true,
                        ["31884"] = false,
                        ["202137"] = false,
                        ["55342"] = true,
                        ["106951"] = false,
                        ["365350"] = false,
                        ["114050"] = false,
                        ["258860"] = false,
                        ["202138"] = false,
                        ["50334"] = false,
                        ["385627"] = false,
                        ["42650"] = false,
                        ["190319"] = false,
                        ["99"] = false,
                        ["102560"] = false,
                        ["384631"] = false,
                        ["228260"] = false,
                        ["12472"] = false,
                        ["360194"] = false,
                        ["275699"] = false,
                        ["391109"] = false,
                        ["288613"] = false,
                        ["262161"] = false,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["198067"] = false,
                        ["1719"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["265187"] = false,
                        ["207289"] = false,
                        ["343721"] = false,
                        ["114051"] = false
                    },
                    ["icons"] = {
                        ["scale"] = 0.7,
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["attach"] = "TOPLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["breakPoint"] = "externalDefensive",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["externalDefensive"] = 0,
                        ["counterCC"] = 2
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                },
                ["noneZoneSetting"] = "party",
                ["arena"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 346.7560630839853,
                                    ["x"] = 202.5780430997475
                                }
                            },
                            ["columns"] = 1,
                            ["scale"] = 1.1
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["columns"] = 10,
                            ["scale"] = 0.79,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["columns"] = 1,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 467.6252717399257,
                                    ["x"] = 895.7523654400939
                                }
                            },
                            ["scale"] = 1,
                            ["sortBy"] = 10
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 169,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["scale"] = 0.65,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 458.9334312516803,
                                    ["x"] = 787.6442899056565
                                }
                            },
                            ["hideSpark"] = true
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["374227"] = true,
                        ["31661"] = true,
                        ["114018"] = true,
                        ["51490"] = true,
                        ["383121"] = true,
                        ["187827"] = true,
                        ["368970"] = true,
                        ["183752"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["386071"] = true,
                        ["371032"] = true,
                        ["157980"] = true,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["200733"] = true,
                        ["396286"] = true,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["209258"] = true,
                        ["121471"] = false,
                        ["102560"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["378279"] = true,
                        ["1719"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["271466"] = true,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["462031"] = true,
                        ["114051"] = false,
                        ["265202"] = true,
                        ["288613"] = false,
                        ["198144"] = false,
                        ["191427"] = false,
                        ["194223"] = false,
                        ["378779"] = true,
                        ["31935"] = true,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["360194"] = false,
                        ["64843"] = true,
                        ["132469"] = true,
                        ["360952"] = false,
                        ["31884"] = false,
                        ["55342"] = true,
                        ["414660"] = true,
                        ["46968"] = true,
                        ["86659"] = true,
                        ["365350"] = false,
                        ["157981"] = true,
                        ["119381"] = true,
                        ["192058"] = true,
                        ["207289"] = false,
                        ["204021"] = true,
                        ["357214"] = true,
                        ["190319"] = false,
                        ["386394"] = true,
                        ["871"] = true,
                        ["114556"] = true,
                        ["228260"] = false,
                        ["186387"] = true,
                        ["12472"] = false,
                        ["205180"] = false,
                        ["391109"] = false,
                        ["49028"] = true,
                        ["106951"] = false,
                        ["114050"] = false,
                        ["116844"] = true,
                        ["132578"] = true,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["265187"] = false,
                        ["30283"] = true,
                        ["110959"] = true,
                        ["23920"] = true
                    },
                    ["icons"] = {
                        ["scale"] = 0.7,
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["attach"] = "TOPLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["offsetY"] = 4,
                        ["breakPoint"] = "externalDefensive",
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["counterCC"] = 2,
                        ["aoeCC"] = 2,
                        ["raidDefensive"] = 3
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    },
                    ["general"] = {
                        ["zoneSelected"] = "party"
                    }
                },
                ["raid"] = {
                    ["extraBars"] = {
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growLeft"] = true,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 411.4667634356374,
                                    ["x"] = 2.933564998877358
                                }
                            },
                            ["scale"] = 1.15,
                            ["locked"] = true,
                            ["columns"] = 7
                        },
                        ["raidBar1"] = {
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 384.2666867077351,
                                    ["x"] = 682.4000355899334
                                }
                            }
                        }
                    },
                    ["spells"] = {
                        ["*"] = false
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                }
            },
            ["General"] = {
                ["fonts"] = {
                    ["statusBar"] = {
                        ["font"] = "Merfin Font 1",
                        ["size"] = 17
                    },
                    ["icon"] = {
                        ["font"] = "Merfin Font 1"
                    },
                    ["anchor"] = {
                        ["font"] = "Merfin Font 1"
                    }
                },
                ["textures"] = {
                    ["statusBar"] = {
                        ["BG"] = "Merfin Main Texture",
                        ["bar"] = "Merfin Main Texture"
                    }
                }
            }
        }
        or MUI:GetProfileResolution() == 'QUAD_HD' and {
            ["Party"] = {
                ["party"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 335.7336763640415,
                                    ["x"] = 256.2670218289077
                                }
                            },
                            ["scale"] = 1.3,
                            ["columns"] = 1
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["locked"] = true,
                            ["scale"] = 0.79,
                            ["columns"] = 10,
                            ["growUpward"] = true,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 195,
                            ["scale"] = 0.7,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 484.0000577946521,
                                    ["x"] = 395.4664594272654
                                }
                            },
                            ["hideSpark"] = true
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 493.2250908278584,
                                    ["x"] = 343.5741064604517
                                }
                            },
                            ["scale"] = 1.2,
                            ["sortBy"] = 10,
                            ["columns"] = 2
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["198067"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["401150"] = false,
                        ["386997"] = false,
                        ["51533"] = false,
                        ["102558"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["152279"] = false,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["123904"] = false,
                        ["258860"] = false,
                        ["265187"] = false,
                        ["31884"] = false,
                        ["202137"] = false,
                        ["55342"] = true,
                        ["365350"] = false,
                        ["106951"] = false,
                        ["360952"] = false,
                        ["202138"] = false,
                        ["50334"] = false,
                        ["385627"] = false,
                        ["42650"] = false,
                        ["190319"] = false,
                        ["99"] = false,
                        ["102560"] = false,
                        ["384631"] = false,
                        ["228260"] = false,
                        ["12472"] = false,
                        ["360194"] = false,
                        ["275699"] = false,
                        ["391109"] = false,
                        ["288613"] = false,
                        ["262161"] = false,
                        ["167105"] = false,
                        ["114050"] = false,
                        ["179057"] = false,
                        ["1719"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["207289"] = false,
                        ["343721"] = false,
                        ["114051"] = false
                    },
                    ["icons"] = {
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["attach"] = "TOPLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["breakPoint"] = "externalDefensive",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["externalDefensive"] = 0,
                        ["counterCC"] = 2
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                },
                ["noneZoneSetting"] = "party",
                ["raid"] = {
                    ["extraBars"] = {
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 369.3329945226324,
                                    ["x"] = 2.400130842136207
                                }
                            },
                            ["scale"] = 1.2,
                            ["columns"] = 7
                        },
                        ["raidBar1"] = {
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 384.2666867077351,
                                    ["x"] = 682.4000355899334
                                }
                            }
                        }
                    },
                    ["spells"] = {
                        ["*"] = false
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                },
                ["arena"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["columns"] = 1,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 316.0005047619598,
                                    ["x"] = 261.6003879924811
                                }
                            },
                            ["scale"] = 1.3
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["columns"] = 10,
                            ["scale"] = 0.79,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 461.2251217110133,
                                    ["x"] = 866.2412561154997
                                }
                            },
                            ["columns"] = 1,
                            ["scale"] = 1.2,
                            ["sortBy"] = 10
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 190,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["scale"] = 0.7,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 452.000056125722,
                                    ["x"] = 765.0663159429823
                                }
                            },
                            ["hideSpark"] = true
                        }
                    },
                    ["general"] = {
                        ["zoneSelected"] = "party"
                    },
                    ["spells"] = {
                        ["374227"] = true,
                        ["31661"] = true,
                        ["114018"] = true,
                        ["51490"] = true,
                        ["383121"] = true,
                        ["187827"] = true,
                        ["183752"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["386071"] = true,
                        ["371032"] = true,
                        ["157980"] = true,
                        ["47528"] = false,
                        ["114050"] = false,
                        ["200733"] = true,
                        ["396286"] = true,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["209258"] = true,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["378279"] = true,
                        ["1719"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["132578"] = true,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["462031"] = true,
                        ["23920"] = true,
                        ["265202"] = true,
                        ["106951"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["378779"] = true,
                        ["31935"] = true,
                        ["375087"] = false,
                        ["205180"] = false,
                        ["403631"] = false,
                        ["360194"] = false,
                        ["102560"] = false,
                        ["132469"] = true,
                        ["360952"] = false,
                        ["31884"] = false,
                        ["55342"] = true,
                        ["414660"] = true,
                        ["46968"] = true,
                        ["86659"] = true,
                        ["365350"] = false,
                        ["157981"] = true,
                        ["119381"] = true,
                        ["192058"] = true,
                        ["207289"] = false,
                        ["64843"] = true,
                        ["204021"] = true,
                        ["357214"] = true,
                        ["190319"] = false,
                        ["386394"] = true,
                        ["871"] = true,
                        ["114556"] = true,
                        ["228260"] = false,
                        ["186387"] = true,
                        ["12472"] = false,
                        ["368970"] = true,
                        ["391109"] = false,
                        ["49028"] = true,
                        ["114051"] = false,
                        ["102543"] = false,
                        ["116844"] = true,
                        ["271466"] = true,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["30283"] = true,
                        ["265187"] = false,
                        ["288613"] = false
                    },
                    ["icons"] = {
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["attach"] = "TOPLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["offsetY"] = 4,
                        ["breakPoint"] = "externalDefensive",
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["counterCC"] = 2,
                        ["aoeCC"] = 2,
                        ["raidDefensive"] = 3
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                }
            },
            ["General"] = {
                ["fonts"] = {
                    ["statusBar"] = {
                        ["font"] = "Merfin Font 1",
                        ["size"] = 17
                    },
                    ["icon"] = {
                        ["font"] = "Merfin Font 1"
                    },
                    ["anchor"] = {
                        ["font"] = "Merfin Font 1"
                    }
                },
                ["textures"] = {
                    ["statusBar"] = {
                        ["BG"] = "Merfin Main Texture",
                        ["bar"] = "Merfin Main Texture"
                    }
                }
            }
        }
    elseif layout == 'Healer-H' then
        OmniCDDB["profiles"][profileName] = 
        MUI:GetProfileResolution() == 'FULL_HD' and {
            ["Party"] = {
                ["party"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["columns"] = 10,
                            ["scale"] = 1.05,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 149.9557110963633,
                                    ["x"] = 506.4003594843962
                                }
                            }
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["locked"] = true,
                            ["scale"] = 0.79,
                            ["columns"] = 10,
                            ["growUpward"] = true,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 180,
                            ["hideSpark"] = true,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 346.5778946768933,
                                    ["x"] = 407.1996626378677
                                }
                            },
                            ["scale"] = 0.65
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 358.8251388970639,
                                    ["x"] = 340.3744657072366
                                }
                            },
                            ["scale"] = 1.1,
                            ["sortBy"] = 10,
                            ["columns"] = 2
                        }
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    },
                    ["spells"] = {
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["198067"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["401150"] = false,
                        ["386997"] = false,
                        ["51533"] = false,
                        ["102558"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["152279"] = false,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["123904"] = false,
                        ["360952"] = false,
                        ["265187"] = false,
                        ["31884"] = false,
                        ["202137"] = false,
                        ["262161"] = false,
                        ["365350"] = false,
                        ["288613"] = false,
                        ["258860"] = false,
                        ["202138"] = false,
                        ["50334"] = false,
                        ["385627"] = false,
                        ["42650"] = false,
                        ["190319"] = false,
                        ["99"] = false,
                        ["102560"] = false,
                        ["384631"] = false,
                        ["228260"] = false,
                        ["12472"] = false,
                        ["360194"] = false,
                        ["275699"] = false,
                        ["391109"] = false,
                        ["114051"] = false,
                        ["55342"] = true,
                        ["167105"] = false,
                        ["114050"] = false,
                        ["179057"] = false,
                        ["1719"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["207289"] = false,
                        ["343721"] = false,
                        ["106951"] = false
                    },
                    ["icons"] = {
                        ["scale"] = 0.67,
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["paddingY"] = -1,
                        ["attachMore"] = "BOTTOMLEFT",
                        ["columns"] = 4,
                        ["paddingX"] = -1,
                        ["breakPoint"] = "externalDefensive",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["attach"] = "BOTTOMLEFT",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPLEFT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["externalDefensive"] = 0,
                        ["counterCC"] = 2
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    }
                },
                ["noneZoneSetting"] = "party",
                ["arena"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 149.9557110963633,
                                    ["x"] = 506.4003594843962
                                }
                            },
                            ["columns"] = 10,
                            ["scale"] = 1.05,
                            ["locked"] = true
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["columns"] = 10,
                            ["scale"] = 0.79,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 180,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["scale"] = 0.65,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 346.5778946768933,
                                    ["x"] = 407.1996626378677
                                }
                            },
                            ["hideSpark"] = true
                        },
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["columns"] = 2,
                            ["locked"] = true,
                            ["offsetX"] = 4,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 358.8251388970639,
                                    ["x"] = 340.3744657072366
                                }
                            },
                            ["scale"] = 1.1,
                            ["sortBy"] = 10
                        }
                    },
                    ["general"] = {
                        ["zoneSelected"] = "party"
                    },
                    ["spells"] = {
                        ["186387"] = true,
                        ["374227"] = true,
                        ["31661"] = true,
                        ["114018"] = true,
                        ["51490"] = true,
                        ["187827"] = true,
                        ["368970"] = true,
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["386071"] = true,
                        ["371032"] = true,
                        ["157980"] = true,
                        ["47528"] = false,
                        ["200733"] = true,
                        ["396286"] = true,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["209258"] = true,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["378279"] = true,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["132578"] = true,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["462031"] = true,
                        ["23920"] = true,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["378779"] = true,
                        ["31935"] = true,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["132469"] = true,
                        ["360952"] = false,
                        ["31884"] = false,
                        ["106951"] = false,
                        ["414660"] = true,
                        ["207289"] = false,
                        ["110959"] = true,
                        ["86659"] = true,
                        ["365350"] = false,
                        ["157981"] = true,
                        ["391528"] = false,
                        ["119381"] = true,
                        ["1719"] = false,
                        ["192058"] = true,
                        ["357214"] = true,
                        ["114050"] = false,
                        ["55342"] = true,
                        ["114051"] = false,
                        ["190319"] = false,
                        ["64843"] = true,
                        ["360194"] = false,
                        ["386394"] = true,
                        ["871"] = true,
                        ["114556"] = true,
                        ["46968"] = true,
                        ["271466"] = true,
                        ["265202"] = true,
                        ["228260"] = false,
                        ["204021"] = true,
                        ["12472"] = false,
                        ["102560"] = false,
                        ["391109"] = false,
                        ["49028"] = true,
                        ["288613"] = false,
                        ["383121"] = true,
                        ["116844"] = true,
                        ["102543"] = false,
                        ["359844"] = false,
                        ["265187"] = false,
                        ["30283"] = true
                    },
                    ["icons"] = {
                        ["scale"] = 0.67,
                        ["desaturateActive"] = true
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["counterCC"] = 2,
                        ["aoeCC"] = 2,
                        ["raidDefensive"] = 3
                    },
                    ["position"] = {
                        ["paddingY"] = -1,
                        ["attachMore"] = "BOTTOMLEFT",
                        ["columns"] = 4,
                        ["paddingX"] = -1,
                        ["breakPoint"] = "externalDefensive",
                        ["attach"] = "BOTTOMLEFT",
                        ["maxNumIcons"] = 7,
                        ["preset"] = "manual",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPLEFT"
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                },
                ["raid"] = {
                    ["extraBars"] = {
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growLeft"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 199.5554952835028,
                                    ["x"] = 480.8003588645079
                                }
                            },
                            ["scale"] = 1,
                            ["columns"] = 5
                        },
                        ["raidBar1"] = {
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 384.2666867077351,
                                    ["x"] = 682.4000355899334
                                }
                            }
                        }
                    },
                    ["spells"] = {
                        ["*"] = false
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                }
            },
            ["General"] = {
                ["textures"] = {
                    ["statusBar"] = {
                        ["BG"] = "Merfin Main Texture",
                        ["bar"] = "Merfin Main Texture"
                    }
                },
                ["fonts"] = {
                    ["statusBar"] = {
                        ["font"] = "Merfin Font 1",
                        ["size"] = 17
                    },
                    ["icon"] = {
                        ["font"] = "Merfin Font 1"
                    },
                    ["anchor"] = {
                        ["font"] = "Merfin Font 1"
                    }
                }
            }
        }
        or MUI:GetProfileResolution() == 'QUAD_HD' and {
            ["Party"] = {
                ["party"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 154.9334716220765,
                                    ["x"] = 510.666921164604
                                }
                            },
                            ["scale"] = 1.3,
                            ["locked"] = true,
                            ["columns"] = 10
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["scale"] = 0.79,
                            ["locked"] = true,
                            ["growUpward"] = true,
                            ["columns"] = 10,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 195,
                            ["hideSpark"] = true,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 340.0001479407219,
                                    ["x"] = 424.7995989779411
                                }
                            },
                            ["scale"] = 0.7
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["columns"] = 2,
                            ["scale"] = 1.2,
                            ["sortBy"] = 10,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 349.7586770955022,
                                    ["x"] = 372.9075389798927
                                }
                            }
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["167105"] = false,
                        ["102543"] = false,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["179057"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["401150"] = false,
                        ["386997"] = false,
                        ["51533"] = false,
                        ["102558"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["152279"] = false,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["123904"] = false,
                        ["360952"] = false,
                        ["288613"] = false,
                        ["31884"] = false,
                        ["202137"] = false,
                        ["55342"] = true,
                        ["365350"] = false,
                        ["110959"] = true,
                        ["258860"] = false,
                        ["202138"] = false,
                        ["1719"] = false,
                        ["50334"] = false,
                        ["385627"] = false,
                        ["42650"] = false,
                        ["190319"] = false,
                        ["99"] = false,
                        ["384631"] = false,
                        ["228260"] = false,
                        ["12472"] = false,
                        ["360194"] = false,
                        ["275699"] = false,
                        ["391109"] = false,
                        ["114051"] = false,
                        ["262161"] = false,
                        ["47528"] = false,
                        ["114050"] = false,
                        ["102560"] = false,
                        ["198067"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["265187"] = false,
                        ["207289"] = false,
                        ["343721"] = false,
                        ["106951"] = false
                    },
                    ["icons"] = {
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["paddingY"] = -1,
                        ["attachMore"] = "BOTTOMLEFT",
                        ["columns"] = 4,
                        ["paddingX"] = -1,
                        ["attach"] = "BOTTOMLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["breakPoint"] = "externalDefensive",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPLEFT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["externalDefensive"] = 0,
                        ["counterCC"] = 2
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                },
                ["noneZoneSetting"] = "party",
                ["arena"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["columns"] = 10,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 154.9334716220765,
                                    ["x"] = 510.666921164604
                                }
                            },
                            ["scale"] = 1.3
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["columns"] = 10,
                            ["scale"] = 0.79,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 424.9585508091477,
                                    ["x"] = 948.37446352408
                                }
                            },
                            ["columns"] = 1,
                            ["scale"] = 1.2,
                            ["sortBy"] = 10
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 190,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["scale"] = 0.7,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 416.2666883766651,
                                    ["x"] = 855.1996539771353
                                }
                            },
                            ["hideSpark"] = true
                        }
                    },
                    ["general"] = {
                        ["zoneSelected"] = "party"
                    },
                    ["spells"] = {
                        ["374227"] = true,
                        ["31661"] = true,
                        ["114018"] = true,
                        ["51490"] = true,
                        ["383121"] = true,
                        ["187827"] = true,
                        ["368970"] = true,
                        ["183752"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["386071"] = true,
                        ["371032"] = true,
                        ["157980"] = true,
                        ["47528"] = false,
                        ["114050"] = false,
                        ["200733"] = true,
                        ["396286"] = true,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["209258"] = true,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["378279"] = true,
                        ["1719"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["132578"] = true,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["462031"] = true,
                        ["23920"] = true,
                        ["265202"] = true,
                        ["207289"] = false,
                        ["198144"] = false,
                        ["102560"] = false,
                        ["194223"] = false,
                        ["378779"] = true,
                        ["31935"] = true,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["360194"] = false,
                        ["64843"] = true,
                        ["132469"] = true,
                        ["360952"] = false,
                        ["31884"] = false,
                        ["55342"] = true,
                        ["414660"] = true,
                        ["46968"] = true,
                        ["86659"] = true,
                        ["365350"] = false,
                        ["157981"] = true,
                        ["119381"] = true,
                        ["192058"] = true,
                        ["271466"] = true,
                        ["204021"] = true,
                        ["357214"] = true,
                        ["190319"] = false,
                        ["386394"] = true,
                        ["871"] = true,
                        ["114556"] = true,
                        ["228260"] = false,
                        ["186387"] = true,
                        ["12472"] = false,
                        ["205180"] = false,
                        ["391109"] = false,
                        ["49028"] = true,
                        ["114051"] = false,
                        ["102543"] = false,
                        ["116844"] = true,
                        ["106951"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["30283"] = true,
                        ["265187"] = false,
                        ["288613"] = false
                    },
                    ["icons"] = {
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["paddingY"] = -1,
                        ["attachMore"] = "BOTTOMLEFT",
                        ["columns"] = 4,
                        ["paddingX"] = -1,
                        ["attach"] = "BOTTOMLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["offsetY"] = 4,
                        ["breakPoint"] = "externalDefensive",
                        ["anchorMore"] = "TOPLEFT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["counterCC"] = 2,
                        ["aoeCC"] = 2,
                        ["raidDefensive"] = 3
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    }
                },
                ["raid"] = {
                    ["extraBars"] = {
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growLeft"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 189.5998796800704,
                                    ["x"] = 489.8667247672893
                                }
                            },
                            ["scale"] = 1.1,
                            ["columns"] = 7
                        },
                        ["raidBar1"] = {
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 384.2666867077351,
                                    ["x"] = 682.4000355899334
                                }
                            }
                        }
                    },
                    ["spells"] = {
                        ["*"] = false
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                }
            },
            ["General"] = {
                ["fonts"] = {
                    ["statusBar"] = {
                        ["font"] = "Merfin Font 1",
                        ["size"] = 17
                    },
                    ["icon"] = {
                        ["font"] = "Merfin Font 1"
                    },
                    ["anchor"] = {
                        ["font"] = "Merfin Font 1"
                    }
                },
                ["textures"] = {
                    ["statusBar"] = {
                        ["BG"] = "Merfin Main Texture",
                        ["bar"] = "Merfin Main Texture"
                    }
                }
            }
        }
    elseif layout == 'Healer-V' then
        OmniCDDB["profiles"][profileName] = 
        MUI:GetProfileResolution() == 'FULL_HD' and {
            ["Party"] = {
                ["party"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 348.1781985350881,
                                    ["x"] = 244.533751580957
                                }
                            },
                            ["scale"] = 1.1,
                            ["columns"] = 1
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["scale"] = 0.79,
                            ["locked"] = true,
                            ["growUpward"] = true,
                            ["columns"] = 10,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 180,
                            ["scale"] = 0.65,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 531.4668965497003,
                                    ["x"] = 407.1999664573195
                                }
                            },
                            ["hideSpark"] = true
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["columns"] = 2,
                            ["scale"] = 1.1,
                            ["sortBy"] = 10,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 543.0032683568243,
                                    ["x"] = 340.3746610197413
                                }
                            }
                        }
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    },
                    ["spells"] = {
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["167105"] = false,
                        ["114050"] = false,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["179057"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["401150"] = false,
                        ["386997"] = false,
                        ["51533"] = false,
                        ["102558"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["152279"] = false,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["123904"] = false,
                        ["258860"] = false,
                        ["110959"] = true,
                        ["31884"] = false,
                        ["202137"] = false,
                        ["262161"] = false,
                        ["1719"] = false,
                        ["365350"] = false,
                        ["102543"] = false,
                        ["360952"] = false,
                        ["202138"] = false,
                        ["102560"] = false,
                        ["50334"] = false,
                        ["385627"] = false,
                        ["42650"] = false,
                        ["190319"] = false,
                        ["99"] = false,
                        ["198067"] = false,
                        ["384631"] = false,
                        ["228260"] = false,
                        ["12472"] = false,
                        ["360194"] = false,
                        ["275699"] = false,
                        ["391109"] = false,
                        ["114051"] = false,
                        ["55342"] = true,
                        ["47528"] = false,
                        ["288613"] = false,
                        ["106951"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["265187"] = false,
                        ["207289"] = false,
                        ["343721"] = false
                    },
                    ["icons"] = {
                        ["scale"] = 0.7,
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["breakPoint"] = "externalDefensive",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["attach"] = "TOPLEFT",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["externalDefensive"] = 0,
                        ["counterCC"] = 2
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    }
                },
                ["noneZoneSetting"] = "party",
                ["arena"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["columns"] = 1,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 348.1781985350881,
                                    ["x"] = 244.533751580957
                                }
                            },
                            ["scale"] = 1.1
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["columns"] = 10,
                            ["scale"] = 0.79,
                            ["locked"] = true,
                            ["growUpward"] = true,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["columns"] = 1,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 467.6252717399257,
                                    ["x"] = 965.4413428220141
                                }
                            },
                            ["scale"] = 1,
                            ["sortBy"] = 10
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 169,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["scale"] = 0.65,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 458.9334312516803,
                                    ["x"] = 858.0445520270223
                                }
                            },
                            ["hideSpark"] = true
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["374227"] = true,
                        ["31661"] = true,
                        ["114018"] = true,
                        ["51490"] = true,
                        ["383121"] = true,
                        ["187827"] = true,
                        ["368970"] = true,
                        ["183752"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["386071"] = true,
                        ["371032"] = true,
                        ["157980"] = true,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["200733"] = true,
                        ["396286"] = true,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["209258"] = true,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["378279"] = true,
                        ["1719"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["132578"] = true,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["462031"] = true,
                        ["265202"] = true,
                        ["23920"] = true,
                        ["288613"] = false,
                        ["198144"] = false,
                        ["102560"] = false,
                        ["194223"] = false,
                        ["378779"] = true,
                        ["31935"] = true,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["360194"] = false,
                        ["64843"] = true,
                        ["132469"] = true,
                        ["360952"] = false,
                        ["31884"] = false,
                        ["55342"] = true,
                        ["414660"] = true,
                        ["46968"] = true,
                        ["86659"] = true,
                        ["365350"] = false,
                        ["157981"] = true,
                        ["119381"] = true,
                        ["192058"] = true,
                        ["30283"] = true,
                        ["204021"] = true,
                        ["357214"] = true,
                        ["190319"] = false,
                        ["386394"] = true,
                        ["871"] = true,
                        ["114556"] = true,
                        ["228260"] = false,
                        ["186387"] = true,
                        ["12472"] = false,
                        ["205180"] = false,
                        ["391109"] = false,
                        ["49028"] = true,
                        ["114051"] = false,
                        ["114050"] = false,
                        ["116844"] = true,
                        ["271466"] = true,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["207289"] = false,
                        ["106951"] = false,
                        ["265187"] = false
                    },
                    ["icons"] = {
                        ["scale"] = 0.7,
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["breakPoint"] = "externalDefensive",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["offsetY"] = 4,
                        ["attach"] = "TOPLEFT",
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["counterCC"] = 2,
                        ["aoeCC"] = 2,
                        ["raidDefensive"] = 3
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    },
                    ["general"] = {
                        ["zoneSelected"] = "party"
                    }
                },
                ["raid"] = {
                    ["extraBars"] = {
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growLeft"] = true,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 411.4667634356374,
                                    ["x"] = 2.933564998877358
                                }
                            },
                            ["scale"] = 1.15,
                            ["locked"] = true,
                            ["columns"] = 7
                        },
                        ["raidBar1"] = {
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 384.2666867077351,
                                    ["x"] = 682.4000355899334
                                }
                            }
                        }
                    },
                    ["spells"] = {
                        ["*"] = false
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                }
            },
            ["General"] = {
                ["textures"] = {
                    ["statusBar"] = {
                        ["BG"] = "Merfin Main Texture",
                        ["bar"] = "Merfin Main Texture"
                    }
                },
                ["fonts"] = {
                    ["statusBar"] = {
                        ["font"] = "Merfin Font 1",
                        ["size"] = 17
                    },
                    ["icon"] = {
                        ["font"] = "Merfin Font 1"
                    },
                    ["anchor"] = {
                        ["font"] = "Merfin Font 1"
                    }
                }
            }
        }
        or MUI:GetProfileResolution() == 'QUAD_HD' and {
            ["Party"] = {
                ["party"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 315.4671714008109,
                                    ["x"] = 291.4670399407733
                                }
                            },
                            ["scale"] = 1.3,
                            ["locked"] = true,
                            ["columns"] = 1
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["locked"] = true,
                            ["scale"] = 0.79,
                            ["columns"] = 10,
                            ["growUpward"] = true,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 195,
                            ["scale"] = 0.7,
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 477.5998621483559,
                                    ["x"] = 424.7998919467063
                                }
                            },
                            ["hideSpark"] = true
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 486.8251555982424,
                                    ["x"] = 373.4414582785721
                                }
                            },
                            ["scale"] = 1.2,
                            ["sortBy"] = 10,
                            ["columns"] = 2
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["183752"] = false,
                        ["205180"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["121471"] = false,
                        ["191427"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["198067"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["401150"] = false,
                        ["386997"] = false,
                        ["51533"] = false,
                        ["102558"] = false,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["152279"] = false,
                        ["375087"] = false,
                        ["403631"] = false,
                        ["123904"] = false,
                        ["258860"] = false,
                        ["106951"] = false,
                        ["31884"] = false,
                        ["202137"] = false,
                        ["55342"] = true,
                        ["179057"] = false,
                        ["365350"] = false,
                        ["114050"] = false,
                        ["360952"] = false,
                        ["202138"] = false,
                        ["50334"] = false,
                        ["385627"] = false,
                        ["42650"] = false,
                        ["190319"] = false,
                        ["99"] = false,
                        ["102560"] = false,
                        ["384631"] = false,
                        ["228260"] = false,
                        ["12472"] = false,
                        ["360194"] = false,
                        ["275699"] = false,
                        ["391109"] = false,
                        ["114051"] = false,
                        ["262161"] = false,
                        ["167105"] = false,
                        ["288613"] = false,
                        ["265187"] = false,
                        ["1719"] = false,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["207289"] = false,
                        ["343721"] = false
                    },
                    ["icons"] = {
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["attach"] = "TOPLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["breakPoint"] = "externalDefensive",
                        ["offsetY"] = 4,
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["externalDefensive"] = 0,
                        ["counterCC"] = 2
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                },
                ["noneZoneSetting"] = "party",
                ["arena"] = {
                    ["extraBars"] = {
                        ["raidBar3"] = {
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growUpward"] = true,
                            ["columns"] = 1,
                            ["manualPos"] = {
                                ["raidBar3"] = {
                                    ["y"] = 315.4671714008109,
                                    ["x"] = 291.4670399407733
                                }
                            },
                            ["scale"] = 1.3
                        },
                        ["raidBar0"] = {
                            ["manualPos"] = {
                                ["raidBar0"] = {
                                    ["y"] = 505.3333271364354,
                                    ["x"] = 372.533678283311
                                }
                            },
                            ["growUpward"] = true,
                            ["locked"] = true,
                            ["scale"] = 0.79,
                            ["columns"] = 10,
                            ["statusBarWidth"] = 230
                        },
                        ["raidBar2"] = {
                            ["offsetX"] = 4,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "CC",
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 424.9585508091477,
                                    ["x"] = 948.37446352408
                                }
                            },
                            ["columns"] = 1,
                            ["scale"] = 1.2,
                            ["sortBy"] = 10
                        },
                        ["raidBar1"] = {
                            ["statusBarWidth"] = 190,
                            ["locked"] = true,
                            ["enabled"] = true,
                            ["hideSpark"] = true,
                            ["growUpward"] = true,
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 416.2666883766651,
                                    ["x"] = 855.1996539771353
                                }
                            },
                            ["scale"] = 0.7
                        }
                    },
                    ["manualPos"] = {
                        {
                            ["y"] = 440.2666896283627,
                            ["x"] = 639.7333666980267
                        },
                        [5] = {
                            ["y"] = 349.066717423997,
                            ["x"] = 685.0667023956776
                        }
                    },
                    ["spells"] = {
                        ["374227"] = true,
                        ["31661"] = true,
                        ["114018"] = true,
                        ["51490"] = true,
                        ["383121"] = true,
                        ["187827"] = true,
                        ["183752"] = false,
                        ["207684"] = false,
                        ["1122"] = false,
                        ["386071"] = true,
                        ["371032"] = true,
                        ["157980"] = true,
                        ["47528"] = false,
                        ["102543"] = false,
                        ["200733"] = true,
                        ["396286"] = true,
                        ["207167"] = false,
                        ["51271"] = false,
                        ["209258"] = true,
                        ["121471"] = false,
                        ["102560"] = false,
                        ["*"] = false,
                        ["107574"] = false,
                        ["378279"] = true,
                        ["1719"] = false,
                        ["137639"] = false,
                        ["10060"] = false,
                        ["132578"] = true,
                        ["13750"] = false,
                        ["231895"] = false,
                        ["462031"] = true,
                        ["23920"] = true,
                        ["265202"] = true,
                        ["30283"] = true,
                        ["198144"] = false,
                        ["194223"] = false,
                        ["378779"] = true,
                        ["31935"] = true,
                        ["375087"] = false,
                        ["205180"] = false,
                        ["403631"] = false,
                        ["360194"] = false,
                        ["191427"] = false,
                        ["132469"] = true,
                        ["360952"] = false,
                        ["31884"] = false,
                        ["55342"] = true,
                        ["414660"] = true,
                        ["46968"] = true,
                        ["86659"] = true,
                        ["365350"] = false,
                        ["157981"] = true,
                        ["119381"] = true,
                        ["192058"] = true,
                        ["106951"] = false,
                        ["64843"] = true,
                        ["204021"] = true,
                        ["357214"] = true,
                        ["190319"] = false,
                        ["386394"] = true,
                        ["871"] = true,
                        ["114556"] = true,
                        ["228260"] = false,
                        ["186387"] = true,
                        ["12472"] = false,
                        ["368970"] = true,
                        ["391109"] = false,
                        ["49028"] = true,
                        ["288613"] = false,
                        ["114050"] = false,
                        ["116844"] = true,
                        ["271466"] = true,
                        ["391528"] = false,
                        ["359844"] = false,
                        ["110959"] = true,
                        ["207289"] = false,
                        ["265187"] = false,
                        ["114051"] = false
                    },
                    ["icons"] = {
                        ["desaturateActive"] = true
                    },
                    ["position"] = {
                        ["anchor"] = "TOPRIGHT",
                        ["paddingY"] = -1,
                        ["attachMore"] = "TOPLEFT",
                        ["columns"] = 3,
                        ["paddingX"] = -1,
                        ["attach"] = "TOPLEFT",
                        ["preset"] = "manual",
                        ["maxNumIcons"] = 7,
                        ["offsetY"] = 4,
                        ["breakPoint"] = "externalDefensive",
                        ["anchorMore"] = "TOPRIGHT"
                    },
                    ["frame"] = {
                        ["disarm"] = 2,
                        ["cc"] = 2,
                        ["counterCC"] = 2,
                        ["aoeCC"] = 2,
                        ["raidDefensive"] = 3
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    },
                    ["general"] = {
                        ["zoneSelected"] = "party"
                    }
                },
                ["raid"] = {
                    ["extraBars"] = {
                        ["raidBar2"] = {
                            ["enabled"] = true,
                            ["layout"] = "horizontal",
                            ["name"] = "Raid Defensives",
                            ["growLeft"] = true,
                            ["locked"] = true,
                            ["columns"] = 6,
                            ["scale"] = 1.1,
                            ["manualPos"] = {
                                ["raidBar2"] = {
                                    ["y"] = 189.599928508198,
                                    ["x"] = 489.3335216144806
                                }
                            }
                        },
                        ["raidBar1"] = {
                            ["manualPos"] = {
                                ["raidBar1"] = {
                                    ["y"] = 384.2666867077351,
                                    ["x"] = 682.4000355899334
                                }
                            }
                        }
                    },
                    ["spells"] = {
                        ["*"] = false
                    },
                    ["spellGlow"] = {
                        ["*"] = false
                    }
                }
            },
            ["General"] = {
                ["fonts"] = {
                    ["statusBar"] = {
                        ["font"] = "Merfin Font 1",
                        ["size"] = 17
                    },
                    ["icon"] = {
                        ["font"] = "Merfin Font 1"
                    },
                    ["anchor"] = {
                        ["font"] = "Merfin Font 1"
                    }
                },
                ["textures"] = {
                    ["statusBar"] = {
                        ["BG"] = "Merfin Main Texture",
                        ["bar"] = "Merfin Main Texture"
                    }
                }
            }
        }
    end 

    OmniCDDB["profileKeys"] = OmniCDDB["profileKeys"] or {}
    OmniCDDB["profileKeys"][addonTable.AceProfileName] = profileName

    addonTable:PluginInstallStepComplete("OmniCD")

end