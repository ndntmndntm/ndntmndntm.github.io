local E, L, V, P, G = unpack(ElvUI)
local IsAddOnLoaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded

function MUI:ClassColorsDB()
    if not IsAddOnLoaded("!ClassColors") then return end

    ClassColorsDB = ClassColorsDB  or {}
    ClassColorsDB.DEATHKNIGHT = {
        b = 0.2509803921568627,
        colorStr = "ffff3f3f",
        g = 0.2509803921568627,
        r = 1,
    }

end