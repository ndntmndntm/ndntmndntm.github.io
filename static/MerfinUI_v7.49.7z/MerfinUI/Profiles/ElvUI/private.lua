local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)

function MUI:PrivateDB()

    E.private.general.chatBubbleFont = addonTable.Font
    E.private.general.chatBubbleFontSize = 10
    E.private.general.chatBubbleName = true
    E.private.general.chatBubbles = "backdrop_noborder"
    E.private.general.dmgfont = addonTable.Font
    E.private.general.glossTex = MUI:GetProfileTexture()
    E.private.general.namefont = addonTable.Font
    E.private.general.nameplateFont = addonTable.Font
    E.private.general.nameplateFontSize = 9
    E.private.general.nameplateLargeFont = addonTable.Font
    E.private.general.nameplateLargeFontSize = 9
    E.private.general.normTex = MUI:GetProfileTexture()
    E.private.general.totemBar = false
    E.private.general.totemTracker = false

    if MUI:GetProfileResolution() == 'QUAD_HD' then
        E.private.general.nameplateFontSize = 9
        E.private.general.nameplateLargeFontSize = 9
    elseif MUI:GetProfileResolution() == 'FULL_HD' then
        E.private.general.nameplateFontSize = 8
        E.private.general.nameplateLargeFontSize = 8
    end

    E.private.install_complete = 2.42

    E.private.nameplates.enable = false
    
    E.private.bags.enable = true
    E.private.bags.bagBar = false
end