local E, L, V, P, G = unpack(ElvUI)

local E, L, V, P, G = unpack(ElvUI)
local IsAddOnLoaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded

function MUI:AddOnSkinsDB(profileName)
    if not IsAddOnLoaded("AddOnSkins") then return end

    AddOnSkinsDB.profiles = AddOnSkinsDB.profiles or {}
    AddOnSkinsDB.profiles.Default = {
        ColorPickerPlus = false,
    }

    AddOnSkinsDB.profileKeys = AddOnSkinsDB.profileKeys or {}
	AddOnSkinsDB.profileKeys[profileName] = "Default"
end