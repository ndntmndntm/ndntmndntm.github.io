local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)
local DT = E:GetModule('DataTexts')

local LoadFilters = function()
    if E.Retail then
        E.global.unitframe.aurafilters.RaidDebuffs.spells = E.global.unitframe.aurafilters.RaidDebuffs.spells or {}
        E.global.unitframe.aurafilters.RaidDebuffs.spells[454439] = E.global.unitframe.aurafilters.RaidDebuffs.spells[454439] or {}
        E.global.unitframe.aurafilters.RaidDebuffs.spells[454439].enable = true
        E.global.unitframe.aurafilters.RaidDebuffs.spells[454439].priority = 0
        E.global.unitframe.aurafilters.RaidDebuffs.spells[454439].stackThreshold = 0
        E.global.unitframe.aurafilters.TurtleBuffs.spells[586] = E.global.unitframe.aurafilters.TurtleBuffs.spells[586] or {}
        E.global.unitframe.aurafilters.TurtleBuffs.spells[586].enable = true
        E.global.unitframe.aurafilters.TurtleBuffs.spells[586].priority = 0
        E.global.unitframe.aurafilters.TurtleBuffs.spells[586].stackThreshold = 0
    end
end

function MUI:GlobalDB()

    ElvDB.global = ElvDB.global or {}
    ElvDB.global.general = ElvDB.global.general or {}

    -- Raid Debuff Indicator
    E.global.unitframe.raidDebuffIndicator = E.global.unitframe.raidDebuffIndicator or {}
    E.global.unitframe.raidDebuffIndicator.otherFilter = "Debuff Indicators"
    E.global.unitframe.raidDebuffIndicator.instanceFilter = "Debuff Indicators"

    DT:BuildPanelFrame('CustomPanel_Left')
	DT:BuildPanelFrame('CustomPanel_Right')

    -- Custom Panels
    E.global.datatexts.customPanels = E.global.datatexts.customPanels or {}
    E.global.datatexts.customPanels.CustomPanel_Left = E.global.datatexts.customPanels.CustomPanel_Left or {}
    E.global.datatexts.customPanels.CustomPanel_Left.backdrop = true
    E.global.datatexts.customPanels.CustomPanel_Left.benikuiStyle = true
    E.global.datatexts.customPanels.CustomPanel_Left.border = true
    E.global.datatexts.customPanels.CustomPanel_Left.enable = false
    E.global.datatexts.customPanels.CustomPanel_Left.fonts = E.global.datatexts.customPanels.CustomPanel_Left.fonts or {}
    E.global.datatexts.customPanels.CustomPanel_Left.fonts.enable = true
    E.global.datatexts.customPanels.CustomPanel_Left.fonts.font = MUI:GetProfileFont('bold')
    E.global.datatexts.customPanels.CustomPanel_Left.fonts.fontOutline = "OUTLINE"
    E.global.datatexts.customPanels.CustomPanel_Left.frameLevel = 1
    E.global.datatexts.customPanels.CustomPanel_Left.frameStrata = "LOW"
    E.global.datatexts.customPanels.CustomPanel_Left.growth = "HORIZONTAL"
    E.global.datatexts.customPanels.CustomPanel_Left.height = 23
    E.global.datatexts.customPanels.CustomPanel_Left.mouseover = false
    E.global.datatexts.customPanels.CustomPanel_Left.name = "CustomPanel_Left"
    E.global.datatexts.customPanels.CustomPanel_Left.numPoints = 2
    E.global.datatexts.customPanels.CustomPanel_Left.panelTransparency = true
    E.global.datatexts.customPanels.CustomPanel_Left.textJustify = "CENTER"
    E.global.datatexts.customPanels.CustomPanel_Left.tooltipAnchor = "ANCHOR_TOPLEFT"
    E.global.datatexts.customPanels.CustomPanel_Left.tooltipXOffset = -17
    E.global.datatexts.customPanels.CustomPanel_Left.tooltipYOffset = 4
    E.global.datatexts.customPanels.CustomPanel_Left.visibility = "[petbattle] hide;show"
    E.global.datatexts.customPanels.CustomPanel_Left.width = 471
    E.global.datatexts.customPanels.CustomPanel_Right = E.global.datatexts.customPanels.CustomPanel_Right or {}
    E.global.datatexts.customPanels.CustomPanel_Right.backdrop = true
    E.global.datatexts.customPanels.CustomPanel_Right.benikuiStyle = true
    E.global.datatexts.customPanels.CustomPanel_Right.border = true
    E.global.datatexts.customPanels.CustomPanel_Right.enable = false
    E.global.datatexts.customPanels.CustomPanel_Right.fonts = E.global.datatexts.customPanels.CustomPanel_Right.fonts or {}
    E.global.datatexts.customPanels.CustomPanel_Right.fonts.enable = true
    E.global.datatexts.customPanels.CustomPanel_Right.fonts.font = MUI:GetProfileFont('bold')
    E.global.datatexts.customPanels.CustomPanel_Right.fonts.fontOutline = "OUTLINE"
    E.global.datatexts.customPanels.CustomPanel_Right.frameLevel = 1
    E.global.datatexts.customPanels.CustomPanel_Right.frameStrata = "LOW"
    E.global.datatexts.customPanels.CustomPanel_Right.growth = "HORIZONTAL"
    E.global.datatexts.customPanels.CustomPanel_Right.height = 23
    E.global.datatexts.customPanels.CustomPanel_Right.mouseover = false
    E.global.datatexts.customPanels.CustomPanel_Right.name = "CustomPanel_Right"
    E.global.datatexts.customPanels.CustomPanel_Right.numPoints = 2
    E.global.datatexts.customPanels.CustomPanel_Right.panelTransparency = true
    E.global.datatexts.customPanels.CustomPanel_Right.textJustify = "CENTER"
    E.global.datatexts.customPanels.CustomPanel_Right.tooltipAnchor = "ANCHOR_TOPLEFT"
    E.global.datatexts.customPanels.CustomPanel_Right.tooltipXOffset = -17
    E.global.datatexts.customPanels.CustomPanel_Right.tooltipYOffset = 4
    E.global.datatexts.customPanels.CustomPanel_Right.visibility = "[petbattle] hide;show"

    if MUI:GetProfileResolution() == 'QUAD_HD' then
        ElvDB.global.general.UIScale = 0.53333333333333
        E.global.datatexts.customPanels.CustomPanel_Left.fonts.fontSize = 14
        E.global.datatexts.customPanels.CustomPanel_Left.height = 23
        E.global.datatexts.customPanels.CustomPanel_Left.width = 471
        E.global.datatexts.customPanels.CustomPanel_Right.fonts.fontSize = 14
        E.global.datatexts.customPanels.CustomPanel_Right.height = 23
        E.global.datatexts.customPanels.CustomPanel_Right.width = 274

    elseif MUI:GetProfileResolution() == 'FULL_HD' then
        ElvDB.global.general.UIScale = 0.71111111111111
        E.global.datatexts.customPanels.CustomPanel_Left.fonts.fontSize = 13
        E.global.datatexts.customPanels.CustomPanel_Left.height = 23
        E.global.datatexts.customPanels.CustomPanel_Left.width = 396
        E.global.datatexts.customPanels.CustomPanel_Right.fonts.fontSize = 13
        E.global.datatexts.customPanels.CustomPanel_Right.height = 23
        E.global.datatexts.customPanels.CustomPanel_Right.width = 230

    end

    LoadFilters()

    E.global.datatexts.settings.Gold.goldFormat = "CONDENSED"

end