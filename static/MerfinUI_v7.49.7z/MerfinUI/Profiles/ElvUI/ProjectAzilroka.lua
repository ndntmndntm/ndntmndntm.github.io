local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)
local IsAddOnLoaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded

function MUI:ProjectAzilrokaDB(profileName)
    if not IsAddOnLoaded("ProjectAzilroka") then return end

    ProjectAzilrokaDB.profiles = ProjectAzilrokaDB.profiles or {}
    ProjectAzilrokaDB.profiles.Default.EnhancedShadows = ProjectAzilrokaDB.profiles.Default.EnhancedShadows or {}
    ProjectAzilrokaDB.profiles.Default.EnhancedShadows.Enable = false
    ProjectAzilrokaDB.profiles.Default.EnhancedShadows.Size = 1
    ProjectAzilrokaDB.profiles.Default.AuraReminder = ProjectAzilrokaDB.profiles.Default.AuraReminder or {}
    ProjectAzilrokaDB.profiles.Default.AuraReminder.Enable = false
    ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList = ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList or {}
    ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.DiffLevel = false
    ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.Texture = MUI:GetProfileTexture()
    ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.Enable = false
    ProjectAzilrokaDB.profiles.Default.DragonOverlay = ProjectAzilrokaDB.profiles.Default.DragonOverlay or {}
    ProjectAzilrokaDB.profiles.Default.DragonOverlay.Enable = false
    ProjectAzilrokaDB.profiles.Default.MovableFrames = ProjectAzilrokaDB.profiles.Default.MovableFrames or {}
    ProjectAzilrokaDB.profiles.Default.MovableFrames.Enable = false
    ProjectAzilrokaDB.profiles.Default.OzCooldowns = ProjectAzilrokaDB.profiles.Default.OzCooldowns or {}
    ProjectAzilrokaDB.profiles.Default.OzCooldowns.Enable = false
    ProjectAzilrokaDB.profiles.Default.QuestSounds = ProjectAzilrokaDB.profiles.Default.QuestSounds or {}
    ProjectAzilrokaDB.profiles.Default.QuestSounds.Enable = false
    ProjectAzilrokaDB.profiles.Default.stAddonManager = ProjectAzilrokaDB.profiles.Default.stAddonManager or {}
    ProjectAzilrokaDB.profiles.Default.stAddonManager.Enable = false
    ProjectAzilrokaDB.profiles.Default.MouseoverAuras = ProjectAzilrokaDB.profiles.Default.MouseoverAuras or {}
    ProjectAzilrokaDB.profiles.Default.MouseoverAuras.Enable = false
    ProjectAzilrokaDB.profiles.Default.FasterLoot = ProjectAzilrokaDB.profiles.Default.FasterLoot or {}
    ProjectAzilrokaDB.profiles.Default.FasterLoot.Enable = false
    ProjectAzilrokaDB.profiles.Default.Cooldown = ProjectAzilrokaDB.profiles.Default.Cooldown or {}
    ProjectAzilrokaDB.profiles.Default.Cooldown.Enable = false
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons = ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons or {}
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.ButtonSpacing = -1
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.ReverseDirection = true
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.MoveMail = false
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.Backdrop = false
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.BarMouseOver = true
    ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.Shadows = false

    if MUI:GetProfileResolution() == 'QUAD_HD' then
        ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.ButtonsPerRow = 3
        ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.IconSize = 25
        ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.InfoFontSize = 14
        ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.NameFontSize = 14

    elseif MUI:GetProfileResolution() == 'FULL_HD' then
        ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.ButtonsPerRow = 3
        ProjectAzilrokaDB.profiles.Default.SquareMinimapButtons.IconSize = 20
        ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.InfoFontSize = 13
        ProjectAzilrokaDB.profiles.Default.EnhancedFriendsList.NameFontSize = 13

    end

    ProjectAzilrokaDB.profileKeys = ProjectAzilrokaDB.profileKeys or {}
    ProjectAzilrokaDB.profileKeys[profileName] = "Default"
end