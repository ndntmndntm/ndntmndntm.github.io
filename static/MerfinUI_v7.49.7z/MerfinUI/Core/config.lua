local addonName, addonTable = ...

local E, L, V, P, G = unpack(ElvUI) 
local PluginInstaller = E:GetModule('PluginInstaller')
local ACD = E.Libs.AceConfigDialog

function MUI:Config()
    ACH = E.Libs.ACH

    -- Main Options
    MUI.Options = ACH:Group(addonTable.Name, nil, 20)

    -- Install Section
    MUI.Options.args.install = ACH:Group('', nil, 1, nil, function(info) return E.private.MUI.general[info[#info]] end, function(info, value) E.private.MUI.general[info[#info]] = value end)
    MUI.Options.args.install.inline = true
    MUI.Options.args.install.args.installer = ACH:Execute(L["UI Install"], L["Re-run the installation process."], 2, function() PluginInstaller:Queue(MUI.InstallerData) E:ToggleOptions() end)
    MUI.Options.args.install.args.quickInstall = ACH:Execute(L["UI Quick Install"], L["Re quick installation process."], 3, function() PluginInstaller:Queue(MUI.InstallerQuick) E:ToggleOptions() end)

    -- Profile Settings
    MUI.Options.args.settings = ACH:Group(L["Installation Settings"], nil, 2, nil, function(info) return E.private.MUI.general.profileSettings[info[#info]] end, function(info, value) E.private.MUI.general.profileSettings[info[#info]] = value end)
    MUI.Options.args.settings.args.header = ACH:Header(L["Installation Settings"], 1)
    MUI.Options.args.settings.args.media = ACH:Group('', nil, 3, nil, function(info) return E.private.MUI.general.profileSettings.media[info[#info]] end, function(info, value) E.private.MUI.general.profileSettings.media[info[#info]] = value end)
    MUI.Options.args.settings.args.media.inline = true
    MUI.Options.args.settings.args.media.args.resolution = ACH:Select(L["Preferable Resolution"], nil, 1, MUI.resolutions)
    MUI.Options.args.settings.args.media.args.texture = ACH:SharedMediaStatusbar(L["Default Texture"], L["The texture that the core of the UI will use."], 2)
    MUI.Options.args.settings.args.actionbars = ACH:Group(L["Action Bars"], nil, 5, nil, function(info) return E.private.MUI.general.profileSettings.actionbars[info[#info]] end, function(info, value) E.private.MUI.general.profileSettings.actionbars[info[#info]] = value; MUI:ActionBarsSettings() end)
    MUI.Options.args.settings.args.actionbars.inline = true
    MUI.Options.args.settings.args.actionbars.args.showGrid = ACH:Toggle(L["Show Grid"], L["Show Empty cells"], 1)
    MUI.Options.args.settings.args.actionbars.args.showMouseover = ACH:Toggle(L["Show Mouseover"], nil, 2)
    MUI.Options.args.settings.args.unitframes = ACH:Group(L["Unit Frames"], nil, 6, nil, function(info) return E.private.MUI.general.profileSettings.unitframes[info[#info]] end, function(info, value) E.private.MUI.general.profileSettings.unitframes[info[#info]] = value end)
    MUI.Options.args.settings.args.unitframes.inline = true
    MUI.Options.args.settings.args.unitframes.args.playerCastBar = ACH:Toggle(L["Player Castbar"], L["Show the Player Cast Bar provided by ElvUI."], 1)
    MUI.Options.args.settings.args.blacklist = ACH:Group(L["Ignore Modules"], nil, 7, nil, function(info) return E.private.MUI.general.profileSettings.blacklist[info[#info]] end, function(info, value) E.private.MUI.general.profileSettings.blacklist[info[#info]] = value end)
    MUI.Options.args.settings.args.blacklist.inline = true
    MUI.Options.args.settings.args.blacklist.args.movers = ACH:Toggle(L["Movers"], nil, 1)
    MUI.Options.args.settings.args.blacklist.args.actionBars = ACH:Toggle(L["Action Bars"], nil, 2)
    MUI.Options.args.settings.args.setDefaults = ACH:Execute(L["Reset to Defaults"], L["Set Default MerfinUI settings"], 8, function() MUI:SetDefaults() end)
    MUI.Options.args.settings.args.setActualVersion = ACH:Execute(L["Set Actual Version"], L["Actualize Profile Version"], 9, function() MUI:SetActualVersion() end)
    
    -- Profiles
    MUI.Options.args.profiles = ACH:Group(L["Profiles"], nil, 2, nil)
    MUI.Options.args.profiles.args.header = ACH:Header(L["Profiles"], 1)
    MUI.Options.args.profiles.args.desc = ACH:Description(L["You can install the profile from this section as an alternative to the installer."], 2, "large")
    MUI.Options.args.profiles.args.spacer1 = ACH:Spacer(3, 'full')

    MUI.Options.args.profiles.args.accountSettings = ACH:Group(L["Account Settings"], nil, 4)
    MUI.Options.args.profiles.args.accountSettings.inline = true
    MUI.Options.args.profiles.args.accountSettings.args.desc = ACH:Description(L["Set important game and addon CVars to recommended values for better visuals, performance, and usability."], 1, "medium")
    MUI.Options.args.profiles.args.accountSettings.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.accountSettings.args.apply = ACH:Execute(L["Load CVars"], nil, 3, function() MUI:Set_CVars() end)

    MUI.Options.args.profiles.args.chatSettings = ACH:Group(L["Chat Settings"], nil, 5)
    MUI.Options.args.profiles.args.chatSettings.inline = true
    MUI.Options.args.profiles.args.chatSettings.args.desc = ACH:Description(L["Set up your chat windows with preconfigured tabs for general, combat log, whispers, and group content."], 1, "medium")
    MUI.Options.args.profiles.args.chatSettings.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.chatSettings.args.apply = ACH:Execute(L["Setup Chat"], nil, 3, function() MUI:SetupChat() end)

    MUI.Options.args.profiles.args.elvuiProfiles = ACH:Group(L["Profiles (ElvUI)"], nil, 6)
    MUI.Options.args.profiles.args.elvuiProfiles.inline = true
    MUI.Options.args.profiles.args.elvuiProfiles.args.desc = ACH:Description(L["Apply my ElvUI layouts for DPS/Tank or Healer roles. Includes both horizontal and vertical layouts for party frames."], 1, "medium")
    MUI.Options.args.profiles.args.elvuiProfiles.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.elvuiProfiles.args.dpsTank = ACH:Execute("DPS/Tank", nil, 3, function() MUI:ImportElvUI("DPS/Tank") end)
    MUI.Options.args.profiles.args.elvuiProfiles.args.healerH = ACH:Execute("Healer-H", nil, 4, function() MUI:ImportElvUI("Healer-H") end)
    MUI.Options.args.profiles.args.elvuiProfiles.args.healerV = ACH:Execute("Healer-V", nil, 5, function() MUI:ImportElvUI("Healer-V") end)

    MUI.Options.args.profiles.args.raidFrames = ACH:Group(L["Raid Frames"], nil, 7, nil, nil, nil, not E.Mists)
    MUI.Options.args.profiles.args.raidFrames.inline = true
    MUI.Options.args.profiles.args.raidFrames.args.desc = ACH:Description(L["Choose between Cell or ElvUI raid frames and apply optimized layouts for raids and dungeons."], 1, "medium")
    MUI.Options.args.profiles.args.raidFrames.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.raidFrames.args.cell = ACH:Execute("Cell", nil, 3, function() MUI:ImportRaidFrames('Cell'); MUI:ApplyCellColorTheme('DARK'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.raidFrames.args.elvui = ACH:Execute("ElvUI Frames", nil, 4, function() MUI:ImportRaidFrames('ElvUI') end)

    MUI.Options.args.profiles.args.nameplates = ACH:Group(L["Nameplates (Plater)"], nil, 8)
    MUI.Options.args.profiles.args.nameplates.inline = true
    MUI.Options.args.profiles.args.nameplates.args.desc = ACH:Description(L["Apply my Plater profile to improve nameplate visibility, customization, and performance."], 1, "medium")
    MUI.Options.args.profiles.args.nameplates.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.nameplates.args.plater = ACH:Execute("Plater", nil, 3, function() MUI:ImportPlater(); E:StaticPopup_Show('MUI_RELOAD') end)

    MUI.Options.args.profiles.args.details = ACH:Group(L["Damage Meter (Details)"], nil, 9)
    MUI.Options.args.profiles.args.details.inline = true
    MUI.Options.args.profiles.args.details.args.desc = ACH:Description(L["Apply a clean and minimalistic Details! profile for tracking damage, healing, and more."], 1, "medium")
    MUI.Options.args.profiles.args.details.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.details.args.detailsButton = ACH:Execute(L["Details"], nil, 3, function() MUI:ImportDetails('DARK') end)

    MUI.Options.args.profiles.args.colorTheme = ACH:Group(L["Color Theme"], nil, 10)
    MUI.Options.args.profiles.args.colorTheme.inline = true
    MUI.Options.args.profiles.args.colorTheme.args.desc = ACH:Description(L["Switch between Normal and Dark color themes for the UI."], 1, "medium")
    MUI.Options.args.profiles.args.colorTheme.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.colorTheme.args.normalTheme = ACH:Execute(L["Normal Theme"], nil, 3, function() MUI:ChangeTheme('NORMAL'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.colorTheme.args.darkTheme = ACH:Execute(L["Dark Theme"], nil, 4, function() MUI:ChangeTheme('DARK'); E:StaticPopup_Show('MUI_RELOAD') end)

    MUI.Options.args.profiles.args.actionBars = ACH:Group(L["Action Bars Visibility"], nil, 11)
    MUI.Options.args.profiles.args.actionBars.inline = true
    MUI.Options.args.profiles.args.actionBars.args.desc = ACH:Description(L["Set your action bars to always show or appear on mouseover."], 1, "medium")
    MUI.Options.args.profiles.args.actionBars.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.actionBars.args.showAlways = ACH:Execute(L["Show Always"], nil, 3, function() MUI:ActionBarsVisibility(true) end)
    MUI.Options.args.profiles.args.actionBars.args.showMouseover = ACH:Execute(L["Show Mouseover"], nil, 4, function() MUI:ActionBarsVisibility(false) end)

    MUI.Options.args.profiles.args.bossMods = ACH:Group(L["Boss Mods"], nil, 12)
    MUI.Options.args.profiles.args.bossMods.inline = true
    MUI.Options.args.profiles.args.bossMods.args.desc = ACH:Description(L["Choose DBM or BigWigs profiles made for raiding. Recommended if not using my Raid Auras."], 1, "medium")
    MUI.Options.args.profiles.args.bossMods.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.bossMods.args.dbmDpsTank = ACH:Execute("DBM DPS/Tank", nil, 3, function() MUI:ImportDBM('DPS/Tank'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.bossMods.args.dbmHealer = ACH:Execute("DBM Healer", nil, 4, function() MUI:ImportDBM('Healer'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.bossMods.args.bigWigs = ACH:Execute("BigWigs", nil, 5, function() MUI:ImportBigWigs(); E:StaticPopup_Show('MUI_RELOAD') end)

    MUI.Options.args.profiles.args.omnicd = ACH:Group("OmniCD", nil, 13, nil, nil, nil, not E.Retail)
    MUI.Options.args.profiles.args.omnicd.inline = true
    MUI.Options.args.profiles.args.omnicd.args.desc = ACH:Description(L["Set up OmniCD to display party cooldowns (defensives, interrupts, raid CDs) with layouts matching your UI."], 1, "medium")
    MUI.Options.args.profiles.args.omnicd.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.omnicd.args.dpsTank = ACH:Execute("DPS/Tank", nil, 3, function() MUI:ImportOmniCD('DPS/Tank'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.omnicd.args.healerH = ACH:Execute("Healer-H", nil, 4, function() MUI:ImportOmniCD('Healer-H'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.omnicd.args.healerV = ACH:Execute("Healer-V", nil, 5, function() MUI:ImportOmniCD('Healer-V'); E:StaticPopup_Show('MUI_RELOAD') end)

    MUI.Options.args.profiles.args.combatText = ACH:Group(L["Combat Text"], nil, 14)
    MUI.Options.args.profiles.args.combatText.inline = true
    MUI.Options.args.profiles.args.combatText.args.desc = ACH:Description(L["Choose Blizzard default combat text or xCT profiles for more compact and customizable numbers."], 1, "medium")
    MUI.Options.args.profiles.args.combatText.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.combatText.args.blizzard = ACH:Execute("Blizzard", nil, 3, function() MUI:Import_xCT("Blizzard"); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.profiles.args.combatText.args.xctDps = ACH:Execute("xCT DPS", nil, 4, function() MUI:Import_xCT("DPS"); E:StaticPopup_Show('MUI_RELOAD') end, nil, nil, nil, nil, nil, E.Classic)
    MUI.Options.args.profiles.args.combatText.args.xctTank = ACH:Execute("xCT Tank", nil, 4, function() MUI:Import_xCT("Tank"); E:StaticPopup_Show('MUI_RELOAD') end, nil, nil, nil, nil, nil, E.Classic)
    MUI.Options.args.profiles.args.combatText.args.xctHealer = ACH:Execute("xCT Healer", nil, 5, function() MUI:Import_xCT("Healer"); E:StaticPopup_Show('MUI_RELOAD') end, nil, nil, nil, nil, nil, E.Classic)

    MUI.Options.args.profiles.args.mrt = ACH:Group("Method Raid Tools", nil, 15)
    MUI.Options.args.profiles.args.mrt.inline = true
    MUI.Options.args.profiles.args.mrt.args.desc = ACH:Description(L["Apply my MRT profile with raid cooldowns and notes preconfigured."], 1, "medium")
    MUI.Options.args.profiles.args.mrt.args.spacer1 = ACH:Spacer(2, 'full')
    MUI.Options.args.profiles.args.mrt.args.mrtButton = ACH:Execute("MethodRaidTools", nil, 3, function() MUI:ImportMRT() end)


    -- Layout Settings
    MUI.Options.args.layout = ACH:Group(L["Color Theme"], nil, 3, nil)
    MUI.Options.args.layout.args.header = ACH:Header(L["Color Theme"], 1)
    MUI.Options.args.layout.args.desc = ACH:Description(L["Click on the button below to set color theme of ElvUI unit frames.\n- Normal Theme would enable class colorized frames;\n- Dark Theme would darken them and put Unit Names texts class colorized"], 2, 'medium')
    MUI.Options.args.layout.args.spacer1 = ACH:Spacer(3, 'full')
    MUI.Options.args.layout.args.darkColor = ACH:Color(L["Main"], nil, 4, true, nil, function() local c = E.private.MUI.general.layout.dark.color return c.r, c.g, c.b, c.a end, function(_, r, g, b, a) local c = E.private.MUI.general.layout.dark.color c.r, c.g, c.b, c.a = r, g, b, a end)
    MUI.Options.args.layout.args.darkColorBackdrop = ACH:Color(L["Backdrop"], nil, 5, true, nil, function() local c = E.private.MUI.general.layout.dark.backdrop return c.r, c.g, c.b, c.a end, function(_, r, g, b, a) local c = E.private.MUI.general.layout.dark.backdrop c.r, c.g, c.b, c.a = r, g, b, a end)
    MUI.Options.args.layout.args.darkColorDeadge = ACH:Color(L["Dead"], nil, 6, true, nil, function() local c = E.private.MUI.general.layout.dark.dead return c.r, c.g, c.b, c.a end, function(_, r, g, b, a) local c = E.private.MUI.general.layout.dark.dead c.r, c.g, c.b, c.a = r, g, b, a end)
    MUI.Options.args.layout.args.spacer2 = ACH:Spacer(7, 'full')
    MUI.Options.args.layout.args.setNormalTheme = ACH:Execute(L["Normal Theme"], nil, 8, function() MUI:ChangeTheme('NORMAL'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.layout.args.setDarkTheme = ACH:Execute(L["Dark Theme"], nil, 9, function() MUI:ChangeTheme('DARK'); E:StaticPopup_Show('MUI_RELOAD') end)
    MUI.Options.args.layout.args.spacer3 = ACH:Spacer(10, 'full')
    MUI.Options.args.layout.args.setDefaults = ACH:Execute(L["Reset to Defaults"], nil, 11, function() MUI:SetDefaultLayout() end)

    -- Links
	MUI.Options.args.links = ACH:Group(L["Links"], nil, 4)
	MUI.Options.args.links.args.header = ACH:Header(L["Links"], 1)
	MUI.Options.args.links.args.discord = ACH:Input('Discord:', nil, 2, nil, 'full', function() return 'https://discord.gg/merfin' end)
    MUI.Options.args.links.args.twitch = ACH:Input('Twitch:', nil, 3, nil, 'full', function() return 'https://twitch.tv/merfin' end)
    MUI.Options.args.links.args.boosty = ACH:Input('Boosty:', nil, 4, nil, 'full', function() return 'https://boosty.to/merfin' end)
    MUI.Options.args.links.args.patreon = ACH:Input('Patreon:', nil, 5, nil, 'full', function() return 'https://www.patreon.com/MerfinUI' end)

    E.Options.args.MUI = MUI.Options
end

--[[
	ACH:Color(name, desc, order, alpha, width, get, set, disabled, hidden)
	ACH:Description(name, order, fontSize, image, imageCoords, imageWidth, imageHeight, width, hidden)
	ACH:Execute(name, desc, order, func, image, confirm, width, get, set, disabled, hidden)
	ACH:Group(name, desc, order, childGroups, get, set, disabled, hidden, func)
	ACH:Header(name, order, get, set, hidden)
	ACH:Input(name, desc, order, multiline, width, get, set, disabled, hidden, validate)
	ACH:MultiSelect(name, desc, order, values, confirm, width, get, set, disabled, hidden)
	ACH:Range(name, desc, order, values, width, get, set, disabled, hidden)
	ACH:Select(name, desc, order, values, confirm, width, get, set, disabled, hidden)
	ACH:Spacer(order, width, hidden)
	ACH:Toggle(name, desc, order, tristate, confirm, width, get, set, disabled, hidden)
]]