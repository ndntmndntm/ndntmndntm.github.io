local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)
local GetAddOnMetadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
local Version = GetAddOnMetadata(addonName, "Version")

local ReloadUI = ReloadUI
local format = string.format
local StopMusic = StopMusic

function addonTable:PluginInstallStepComplete(plugin)
	PluginInstallStepComplete:Hide()
    PluginInstallStepComplete.message = string.format("%s Installed!", plugin)
    PluginInstallStepComplete:Show()
end

function addonTable:InstallComplete()
	if GetCVarBool("Sound_EnableMusic") then
		StopMusic()
	end

	E.global.MUI.install_version = Version
	E.private.MUI.install_version = Version

	ReloadUI()
end

MUI.InstallerData = {

	Title = format("|cff4beb2c%s %s|r", addonTable.Name, "Installation"),
	Name = addonTable.Name,
	tutorialImage = "Interface\\AddOns\\MerfinUI\\Media\\Textures\\logo.png",

	Pages = {
		[1] = function()
			PluginInstallFrame.SubTitle:SetFormattedText(L["Welcome to the installation for %s."], addonTable.Name.." "..Version)
			PluginInstallFrame.Desc1:SetText(L["This installer contains profiles for various addons in MerfinUI."])
			PluginInstallFrame.Desc2:SetText(L["Before starting the installation process, I highly recommend backing up your current WTF folder to preserve your existing settings, just in case."])
			PluginInstallFrame.Desc3:SetText(L["Don't forget to click Finished in the final step. This will reload your UI and apply all the settings."])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", addonTable.InstallComplete)
			PluginInstallFrame.Option1:SetText(L["Skip Process"])
		end,

		[2] = function()
			PluginInstallFrame.SubTitle:SetText(L["Account Settings"])
			PluginInstallFrame.Desc1:SetText(L["The World of Warcraft game client stores all its configurations in console variables (CVars). These variables control various aspects of the game, including graphics, sound, and the user interface."])
			PluginInstallFrame.Desc2:SetText(L["This step also includes settings for addons like Questie and Leatrix."])
			PluginInstallFrame.Desc3:SetText(L['Importance: |cff4beb2cOptional|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:Set_CVars() end)
			PluginInstallFrame.Option1:SetText(L["Load CVars"])
		end,

		[3] = function()
			PluginInstallFrame.SubTitle:SetText(L["Chat Settings"])
			PluginInstallFrame.Desc1:SetText(L["This will set up the chat windows to look like this:\n\nGNL - Clog - LT - /W - LFG."])
			PluginInstallFrame.Desc2:SetText(L['Importance: |cff4beb2cOptional|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:SetupChat() end)
			PluginInstallFrame.Option1:SetText(L["Setup Chat"])
		end,

		[4] = function()
			PluginInstallFrame.SubTitle:SetText(L["Profiles (ElvUI)"])
			PluginInstallFrame.Desc1:SetText(L["Click the button below to apply the layout of your choice, depending on your role: DPS/Tank or Healer. Use Healer-H if you prefer horizontal party frames (similar to your raid frames). Choose Healer-V if you'd like your party frames to grow vertically. I personally prefer the vertical layout, but it's up to you!"])
			PluginInstallFrame.Desc2:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportElvUI("DPS/Tank") end)
			PluginInstallFrame.Option1:SetText("DPS/Tank")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:ImportElvUI("Healer-H") end)
			PluginInstallFrame.Option2:SetText("Healer-H")
			PluginInstallFrame.Option3:Show()
			PluginInstallFrame.Option3:SetScript("OnClick", function() MUI:ImportElvUI("Healer-V") end)
			PluginInstallFrame.Option3:SetText("Healer-V")
		end,

		[(E.Mists and 5) or false] = function()
			PluginInstallFrame.SubTitle:SetText(L["Raid Frames"])
			PluginInstallFrame.Desc1:SetText(L["Cell is a standalone addon included in my AddOns pack. It’s a powerful raid frame addon inspired by some of the best—CompactRaid, Grid2, Aptechka, and VuhDo. With its user-friendly interface, Cell offers a smoother and more intuitive experience than ever before."])
			PluginInstallFrame.Desc2:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportRaidFrames('Cell') end)
			PluginInstallFrame.Option1:SetText("Cell")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:ImportRaidFrames('ElvUI') end)
			PluginInstallFrame.Option2:SetText("ElvUI Frames")
		end,

		[(E.Mists and 6) or 5] = function()
			PluginInstallFrame.SubTitle:SetText(L["Nameplates (Plater)"])
			PluginInstallFrame.Desc1:SetText(L["Click the button to adjust the settings."])
			PluginInstallFrame.Desc2:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportPlater() end)
			PluginInstallFrame.Option1:SetText("Plater")
		end,

		[(E.Mists and 7) or 6] = function()
			PluginInstallFrame.SubTitle:SetText("Damage Meter (Details)")
			PluginInstallFrame.Desc1:SetText(L["Click the button to adjust the settings."])
			PluginInstallFrame.Desc3:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportDetails('DARK') end)
			PluginInstallFrame.Option1:SetText(L["Details"])
		end,

		[(E.Mists and 8) or 7] = function()
			PluginInstallFrame.SubTitle:SetText("Color Theme")
			PluginInstallFrame.Desc1:SetText(L["Click on the button to set color theme."])
			PluginInstallFrame.Desc3:SetText(L['Importance: |cff4beb2cOptional|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ChangeTheme('NORMAL') end)
			PluginInstallFrame.Option1:SetText(L["Normal Theme"])
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:ChangeTheme('DARK') end)
			PluginInstallFrame.Option2:SetText(L["Dark Theme"])
		end,

		[(E.Mists and 9) or 8] = function()
			PluginInstallFrame.SubTitle:SetText("Action Bars Visibility")
			PluginInstallFrame.Desc1:SetText(L["Click on the button to set color theme."])
			PluginInstallFrame.Desc3:SetText(L['Importance: |cff4beb2cOptional|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ActionBarsVisibility(true) end)
			PluginInstallFrame.Option1:SetText(L["Show Always"])
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:ActionBarsVisibility(false) end)
			PluginInstallFrame.Option2:SetText(L["Show Mouseover"])
		end,

		[not E.Mists and 9] = function()
			PluginInstallFrame.SubTitle:SetText("Boss Mods")
			PluginInstallFrame.Desc1:SetText(L["Choose DBM if you prefer to play with DBM, or BigWigs if you're a fan of that addon. You can skip this step if you're using my Raid Auras, as they already include everything needed for raids."])
			PluginInstallFrame.Desc2:SetText(L['Importance: |cff4beb2cHigh|r'])

			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportDBM('DPS/Tank') end)
			PluginInstallFrame.Option1:SetText("DBM DPS/Tank")

			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:ImportDBM('Healer') end)
			PluginInstallFrame.Option2:SetText("DBM Healer")
			
			PluginInstallFrame.Option3:Show()
			PluginInstallFrame.Option3:SetScript("OnClick", function() MUI:ImportBigWigs() end)
			PluginInstallFrame.Option3:SetText("BigWigs")
		end,

		[E.Retail and 10] = function()
			PluginInstallFrame.SubTitle:SetText("OmniCD")
			PluginInstallFrame.Desc1:SetText(L["Click the button to adjust the settings."])
			PluginInstallFrame.Desc2:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Desc3:SetText(L['OmniCD is used to display the cooldowns of your party, divided into several categories: Self Defensives, CC, Interrupts, and Raid Defensives. Depending on the layout you choose, the placement of the panels will vary. Use the same layout that you selected in ElvUI.'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportOmniCD('DPS/Tank') end)
			PluginInstallFrame.Option1:SetText("DPS/Tank")
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:ImportOmniCD('Healer-H') end)
			PluginInstallFrame.Option2:SetText("Healer-H")
			PluginInstallFrame.Option3:Show()
			PluginInstallFrame.Option3:SetScript("OnClick", function() MUI:ImportOmniCD('Healer-V') end)
			PluginInstallFrame.Option3:SetText("Healer-V")
		end,

		[(E.Classic or E.Wrath or E.Cata) and 10 or (E.Mists and 10) or (E.Retail and 11)] = function()
			PluginInstallFrame.SubTitle:SetText(L["Combat Text"])
			PluginInstallFrame.Desc1:SetText(L["Here you can choose how to display Combat Text (damage, healing numbers, etc.). If you prefer the normal numbers above the mobs, click on Blizzard. If you prefer damage numbers to be stacked in one place, use xCT — either xCT DPS/Tank or xCT Healer, depending on your spec."])
			PluginInstallFrame.Desc2:SetText(L["ATM Classic Vanilla doesn't support xCT."])
			PluginInstallFrame.Desc3:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:Import_xCT("Blizzard") end)
			PluginInstallFrame.Option1:SetText("Blizzard")
			if not E.Classic then
				PluginInstallFrame.Option2:Show()
				PluginInstallFrame.Option2:SetScript("OnClick", function() MUI:Import_xCT("DPS") end)
				PluginInstallFrame.Option2:SetText("xCT DPS")
				PluginInstallFrame.Option3:Show()
				PluginInstallFrame.Option3:SetScript("OnClick", function() MUI:Import_xCT("Tank") end)
				PluginInstallFrame.Option3:SetText("xCT Tank")
				PluginInstallFrame.Option4:Show()
				PluginInstallFrame.Option4:SetScript("OnClick", function() MUI:Import_xCT("Healer") end)
				PluginInstallFrame.Option4:SetText("xCT Healer")
			end
		end,

		[(E.Classic or E.Wrath or E.Cata) and 11 or (E.Mists and 11) or (E.Retail and 12)] = function()
			PluginInstallFrame.SubTitle:SetText("Method Raid Tools")
			PluginInstallFrame.Desc1:SetText(L["Click the button to adjust the settings."])
			PluginInstallFrame.Desc2:SetText(L['Profile contains settings for Raid Cooldowns and Notes'])			
			PluginInstallFrame.Desc3:SetText(L['Importance: |cff4beb2cHigh|r'])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI:ImportMRT() end)
			PluginInstallFrame.Option1:SetText("MethodRaidTools")
		end,

		[(E.Classic or E.Wrath or E.Cata) and 12 or (E.Mists and 12) or (E.Retail and 13)] = function()
			PluginInstallFrame.SubTitle:SetText(L["Installation Complete"])
			PluginInstallFrame.Desc1:SetText(L["You have completed the installation process."])
			PluginInstallFrame.Desc2:SetText(L["You must click the button below to finalize the process and automatically reload your UI."])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", addonTable.InstallComplete)
			PluginInstallFrame.Option1:SetText(L["Finished"])
		end
	},
	
	StepTitles = {
		[1] = L["Welcome"],
		[2] = L["Account Settings"],
		[3] = L["Chat Settings"],
		[4] = L["Profiles (ElvUI)"],
		[(E.Mists and 5) or false] = L["Raid Frames"],
		[(E.Mists and 6) or 5] = L["Nameplates (Plater)"],
		[(E.Mists and 7) or 6] = "Damage Meter (Details)",
		[(E.Mists and 8) or 7] = "Color Theme",
		[(E.Mists and 9) or 8] = "Action Bars",
		[not E.Mists and 9] = "Boss Mods",
		[E.Retail and 10] = "OmniCD",
		[(E.Classic or E.Wrath or E.Cata) and 10 or (E.Mists and 10) or (E.Retail and 11)] = L["Combat Text (xCT+)"],
		[(E.Classic or E.Wrath or E.Cata) and 11 or (E.Mists and 11) or (E.Retail and 12)] = "Method Raid Tools",
		[(E.Classic or E.Wrath or E.Cata) and 12 or (E.Mists and 12) or (E.Retail and 13)] = L["Installation Complete"]
	},

	StepTitlesColor = { 1, 1, 1 },
	StepTitlesColorSelected = { 0, 179/255, 1 },
	StepTitleWidth = 200,
	StepTitleButtonWidth = 180,
	StepTitleTextJustification = "RIGHT",
	
}

MUI.QuickInstall = function(layout)

	MUI:Set_CVars()

	MUI:SetupChat()

	MUI:ImportPlater()

	MUI:ImportMRT()

	MUI:ImportDetails('NORMAL')

	MUI:ImportElvUI(layout)

	if E.Retail then
		MUI:ImportBigWigs()
	else
		MUI:ImportDBM(layoutFixed)
	end
	
	if E.Retail or E.Cata then
		MUI:ImportOmniCD(layout)
	end

	if not E.Classic then
		MUI:Import_xCT(layout)
	end

	if E.Mists then
		MUI:ImportRaidFrames('Cell')
		MUI:ApplyCellColorTheme('DARK')
	end

	addonTable:InstallComplete()

end

MUI.InstallerQuick = {

	Title = format("|cff4beb2c%s %s|r", addonTable.Name, "Quick Installation"),
	Name = addonTable.Name,
	tutorialImage = "Interface\\AddOns\\MerfinUI\\Media\\Textures\\logo.png",

	Pages = {
		[1] = function()
			PluginInstallFrame.SubTitle:SetFormattedText(L["Welcome to the Quick installation for %s."], addonTable.Name.." "..Version)
			PluginInstallFrame.Desc1:SetText(L["This installer will quickly set up all addons and profiles (except for WeakAuras, as neither the full installer currently handles WeakAuras). With just one click, everything will be configured, followed by a reload at the end. If you're unsure, consider using the standard installer instead."])
			--PluginInstallFrame.Desc2:SetText(L["DPS/Tank refers to the layout designed for DPS and Tank roles. Healer-H is for the Healer layout with horizontally growing party frames, while Healer-V provides a layout with vertically growing party frames"])
			PluginInstallFrame.Option1:Show()
			PluginInstallFrame.Option1:SetScript("OnClick", function() MUI.QuickInstall('DPS/Tank') end)
			PluginInstallFrame.Option1:SetText(L["DPS/Tank"])
			PluginInstallFrame.Option2:Show()
			PluginInstallFrame.Option2:SetScript("OnClick", function() MUI.QuickInstall('Healer') end)
			PluginInstallFrame.Option2:SetText(L["Healer"])
		end,

	},

	StepTitles = {
		[1] = L["Quick Install"],
	},

	StepTitlesColor = { 1, 1, 1 },
	StepTitlesColorSelected = { 0, 179/255, 1 },
	StepTitleWidth = 200,
	StepTitleButtonWidth = 180,
	StepTitleTextJustification = "RIGHT",

}
