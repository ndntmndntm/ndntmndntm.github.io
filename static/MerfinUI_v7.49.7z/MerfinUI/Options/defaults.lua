local E, L, V, P, G = unpack(ElvUI)
local addonName, addonTable = ...

MUI.resolutions = {
    FULL_HD = 'Full HD (1920-1080px)',
    QUAD_HD = 'Quad HD (2560-1440px)',
}

V.MUI = {
    general = {
        profileSettings = {
            media = {
                resolution = addonTable.Resolution,
                texture = addonTable.Texture,
            },
            actionbars = {
                showGrid = false,
                showMouseover = true,
            },
            unitframes = {
                playerCastBar = (E.Retail and true) or false,
                useElvIndicators = false,
            },
            blacklist = {
                movers = false,
                actionBars = false,
            }
        },
        layout = {
            dark = {
                color = { r = 0.1803921568627451, g = 0.1607843137254902, b = 0.1607843137254902, a = 1 },
                backdrop = { r = 0.5490196078431373, g = 0.4549019607843137, b = 0.4549019607843137, a = 1 },
                dead = { r = 0.65882352941176, g = 0.086274509803922, b = 0.086274509803922, a = 1 },
            }
        },
    }
}

-- E.global
G.MUI = {
}
