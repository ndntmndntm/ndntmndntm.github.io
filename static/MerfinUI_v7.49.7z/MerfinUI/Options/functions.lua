local addonName, addonTable = ...
local E, L, V, P, G = unpack(ElvUI)
local AB = E:GetModule('ActionBars')
local UF = E:GetModule('UnitFrames')
local LSM = LibStub:GetLibrary("LibSharedMedia-3.0")

local individualUnits = { 'player', 'pet', 'pettarget', 'target', 'targettarget', 'targettargettarget', 'focus', 'focustarget' }
local groupUnits = { 'party', 'raid1', 'raid2', 'raid3' }
local customTexts = { 'UnitHealth', 'UnitName', 'UnitPower', 'DeadGhostStatus', 'OfflineStatus' }

-- @returns mouseover, showGrid bool
function MUI:GetActionBarsSettings()
    local mouseover = E.private.MUI.general.profileSettings.actionbars.showMouseover
    local showGrid = E.private.MUI.general.profileSettings.actionbars.showGrid
    return mouseover, showGrid
end

-- @returns preferable resolution (default otherwise)
function MUI:GetProfileResolution()
    local profileResolution = E.private.MUI.general.profileSettings.media.resolution
    return profileResolution or addonTable.Resolution
end

-- @returns main db font (default otherwise)
function MUI:GetProfileFont(style)
    local profileFont = E.private.MUI.general.profileSettings.media.font
    if profileFont == 'SFUIDisplayCondensed-Semibold' and style == 'bold' then
        return 'SFUIDisplayCondensed-Bold'
    end
    return profileFont or addonTable.Font
end

-- @returns main db font for numbers (default otherwise)
function MUI:GetProfileNumberFont()
    local profileFont = E.private.MUI.general.profileSettings.media.fontNumbers
    return profileFont or addonTable.Font
end

-- @returns main db texture (default otherwise)
function MUI:GetProfileTexture()
    local profileTexture = E.private.MUI.general.profileSettings.media.texture
    return profileTexture or addonTable.Texture
end

-- @returns dark main color, dark backdrop color
function MUI:GetDarkThemeColors()
    local color = E.private.MUI.general.layout.dark.color
    local backdropColor = E.private.MUI.general.layout.dark.backdrop
    local dead = E.private.MUI.general.layout.dark.dead
    return color, backdropColor, dead
end

-- @returns path for media file
function MUI:GetMediaPath(mediaType, key)
    local hashTable = LSM:HashTable(mediaType)
    if not hashTable then return '' end
    return hashTable[key]
end

-- @returns player cast bar isEnabled
function MUI:GetPlayerCastBar()
    return E.private.MUI.general.profileSettings.unitframes.playerCastBar
end

-- @returns dark main color, dark backdrop color
function MUI:GetBlacklist(info)
    return E.private.MUI.general.profileSettings.blacklist[info]
end

function MUI:ActionBarsSettings()

    local mouseover, showGrid = MUI:GetActionBarsSettings()

    for i = 1, 6 do
        E.db.actionbar["bar"..i].mouseover = mouseover
        E.db.actionbar["bar"..i].showGrid = showGrid
    end

    E.db.general.totems = E.db.general.totems or {}

    E.db.actionbar.barPet.mouseover = mouseover
    E.db.actionbar.microbar.mouseover = mouseover
    E.db.actionbar.stanceBar.mouseover = mouseover
    E.db.general.totems.mouseover = mouseover

    E.db.actionbar.barPet.showGrid = showGrid
    E.db.actionbar.microbar.showGrid = showGrid
    E.db.actionbar.stanceBar.showGrid = showGrid
    E.db.general.totems.showGrid = showGrid

    E:UpdateActionBars()
end

function MUI:ActionBarsVisibility(isAlways)

    local mouseover = not isAlways

    E.private.MUI.general.profileSettings.actionbars.showMouseover = mouseover

    for i = 1, 6 do
        E.db.actionbar["bar"..i].mouseover = mouseover
    end

    E.db.general.totems = E.db.general.totems or {}

    E.db.actionbar.barPet.mouseover = mouseover
    E.db.actionbar.microbar.mouseover = mouseover
    E.db.actionbar.stanceBar.mouseover = mouseover
    E.db.general.totems.mouseover = mouseover

    E:UpdateActionBars()
end

function MUI:ChangeTheme(theme)

    if theme == 'DARK' then

        for unitFrame in pairs(E.db.unitframe.units) do
            E.db.unitframe.units[unitFrame].colorOverride = "FORCE_OFF"
        end
    
        E.db.unitframe.colors.useDeadBackdrop = true
        E.db.unitframe.colors.transparentHealth = true

        local color, backdropColor, dead = MUI:GetDarkThemeColors()

        E.db.unitframe.colors.health.b = color.b
        E.db.unitframe.colors.health.g = color.g
        E.db.unitframe.colors.health.r = color.r
        E.db.unitframe.colors.health_backdrop.b = backdropColor.b
        E.db.unitframe.colors.health_backdrop.g = backdropColor.g
        E.db.unitframe.colors.health_backdrop.r = backdropColor.r
        E.db.unitframe.colors.health_backdrop_dead.b = dead.b
        E.db.unitframe.colors.health_backdrop_dead.g = dead.g
        E.db.unitframe.colors.health_backdrop_dead.r = dead.r

        local groupFrames = { 'party', 'raid1', 'raid2', 'raid3', 'boss' }

        for _, groupFrame in ipairs(groupFrames) do
            if E.db.unitframe.units[groupFrame].customTexts then
                if E.db.unitframe.units[groupFrame].customTexts.UnitName then
                    E.db.unitframe.units[groupFrame].customTexts.UnitName.text_format = "[classcolor][name:veryshort]"
                end
            end
        end

        local individualFrames = { 'target', 'targettarget', 'focus', 'focustarget', 'tank' }

        for _, individualFrame in ipairs(individualFrames) do
            if E.db.unitframe.units[individualFrame].customTexts then
                if E.db.unitframe.units[individualFrame].customTexts.UnitName then
                    E.db.unitframe.units[individualFrame].customTexts.UnitName.text_format = "[classcolor][name:medium]"
                end
            end
        end

        MUI:ImportDetails('DARK')

        if E.Mists then
            MUI:ApplyCellColorTheme('DARK')
        end

        addonTable:PluginInstallStepComplete('Dark Theme Applied')

    elseif theme == 'NORMAL' then

        for unitFrame in pairs(E.db.unitframe.units) do
            E.db.unitframe.units[unitFrame].colorOverride = "FORCE_ON"
        end

        E.db.unitframe.colors.useDeadBackdrop = false
        E.db.unitframe.colors.transparentHealth = false
    
        E.db.unitframe.colors.health.b = 0.17254901960784
        E.db.unitframe.colors.health.g = 0.17254901960784
        E.db.unitframe.colors.health.r = 0.1921568627451
        E.db.unitframe.colors.health_backdrop.b = 0.12549019607843
        E.db.unitframe.colors.health_backdrop.g = 0.12549019607843
        E.db.unitframe.colors.health_backdrop.r = 0.14901960784314
        E.db.unitframe.colors.health_backdrop_dead.b = 0.46274509803922
        E.db.unitframe.colors.health_backdrop_dead.g = 0.46274509803922
        E.db.unitframe.colors.health_backdrop_dead.r = 0.51764705882353

        local groupFrames = { 'party', 'raid1', 'raid2', 'raid3' }

        for _, groupFrame in ipairs(groupFrames) do
            if E.db.unitframe.units[groupFrame].customTexts.UnitName then 
                E.db.unitframe.units[groupFrame].customTexts.UnitName.text_format = "[name:veryshort]"
            end
        end

        groupFrames = { 'target', 'targettarget', 'focus', 'focustarget', 'tank' }

        for _, groupFrame in ipairs(groupFrames) do
            if E.db.unitframe.units[groupFrame].customTexts.UnitName then
                E.db.unitframe.units[groupFrame].customTexts.UnitName.text_format = "[name:medium]"
            end
        end

        MUI:ImportDetails('NORMAL')
        MUI:ApplyCellColorTheme('NORMAL')

        addonTable:PluginInstallStepComplete('Normal Theme Applied')
    end

    E:UpdateUnitFrames()
end

function MUI:SetDefaultLayout()
    E.private.MUI.general.layout.dark.color = { r = 0.1803921568627451, g = 0.1607843137254902, b = 0.1607843137254902, a = 1 }
    E.private.MUI.general.layout.dark.backdrop = { r = 0.5490196078431373, g = 0.4549019607843137, b = 0.4549019607843137, a = 1 }
    E.private.MUI.general.layout.dark.dead = { r = 1, g = 0.25098039215686, b = 0.25098039215686, a = 1 }
end

function MUI:SetDefaults()
    E.private.MUI.general.profileSettings.media.resolution = addonTable.Resolution
    E.private.MUI.general.profileSettings.media.font = addonTable.Font
    E.private.MUI.general.profileSettings.media.texture = addonTable.Texture
    E.private.MUI.general.profileSettings.actionbars.showMouseover = true
    E.private.MUI.general.profileSettings.actionbars.showGrid = false
    E.private.MUI.general.profileSettings.blacklist.movers = false
    E.private.MUI.general.profileSettings.blacklist.actionBars = false
    MUI:ActionBarsSettings()
end

function MUI:ChangeFontWA()

end

function MUI:SetActualVersion()
    local Version = GetAddOnMetadata(addonName, "Version")
	E.global.MUI.install_version = Version
	E.private.MUI.install_version = Version
    DEFAULT_CHAT_FRAME:AddMessage('|cffffff00MerfinUI:|r profile version was changed to recent v' .. Version)
end

local fontSizeAdd = {
    ['Expressway'] = -1,
}
function MUI:SetFontSize(default)
    local font = addonTable.Font
    local add = fontSizeAdd[font]
    if add then
        return default + add
    end
    return default
end